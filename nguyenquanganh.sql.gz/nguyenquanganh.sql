-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 11, 2021 lúc 06:24 PM
-- Phiên bản máy phục vụ: 10.4.19-MariaDB
-- Phiên bản PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `pro_manageuser_nguyenquanganh`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `mst_group`
--

CREATE TABLE `mst_group` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `mst_group`
--

INSERT INTO `mst_group` (`group_id`, `group_name`) VALUES
(1, 'Phòng phát triển số 1'),
(2, 'Phòng phát triển số 2'),
(3, 'Phòng phát triển số 3'),
(4, 'Phòng phát triển số 4');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `mst_japan`
--

CREATE TABLE `mst_japan` (
  `code_level` varchar(15) NOT NULL,
  `name_level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `mst_japan`
--

INSERT INTO `mst_japan` (`code_level`, `name_level`) VALUES
('N1', ' trình độ tiếng nhật cấp N1'),
('N2', ' trình độ tiếng nhật cấp N2'),
('N3', ' trình độ tiếng nhật cấp N3'),
('N4', ' trình độ tiếng nhật cấp N4'),
('N5', ' trình độ tiếng nhật cấp N5');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_detail_user_japan`
--

CREATE TABLE `tbl_detail_user_japan` (
  `detail_user_japan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code_level` varchar(15) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `tbl_detail_user_japan`
--

INSERT INTO `tbl_detail_user_japan` (`detail_user_japan_id`, `user_id`, `code_level`, `start_date`, `end_date`, `total`) VALUES
(1, 1, 'N5', '2005-07-08', '2006-07-08', 90),
(2, 4, 'N1', '2005-05-20', '2005-05-20', 100),
(14, 48, 'N2', '2008-06-24', '2009-11-26', 123),
(15, 52, 'N1', '2016-11-26', '2020-11-26', 321),
(18, 57, 'N1', '2017-09-24', '2020-11-26', 123),
(20, 59, 'N2', '2015-11-26', '2020-11-26', 123),
(21, 60, 'N3', '2019-11-26', '2020-11-26', 123),
(25, 66, 'N2', '2019-11-26', '2020-11-26', 123),
(27, 72, 'N3', '2019-12-02', '2020-12-02', 120),
(29, 77, 'N3', '1997-05-18', '2015-03-29', 120),
(30, 78, 'N5', '2019-12-03', '2019-12-18', 12),
(32, 80, 'N5', '2019-07-23', '2020-12-06', 123);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `login_name` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `full_name_kana` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `birthday` date NOT NULL,
  `rule` int(1) NOT NULL,
  `salt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `group_id`, `login_name`, `password`, `full_name`, `full_name_kana`, `email`, `tel`, `birthday`, `rule`, `salt`) VALUES
(1, 1, 'ntmhuong', '929c447cdf6981e222895c4813a7a2946355ed4e', 'Nguyễn Thị Mai Hương', 'Hương Kana', 'huong@gmail.com', '123456789', '1983-07-08', 0, 'abcxyz1'),
(2, 1, 'hieudt', '123456', 'Đoàn Trọng Hiếu', 'Hiếu Kana', 'hieu@gmali.com', '987456123', '1983-08-08', 1, 'abcxyz2'),
(3, 2, 'longth', '123456', 'Trần Hoàng Long', 'Long Kana', 'long@gmail.com', '654123789', '1983-09-08', 1, 'abcxyz3'),
(4, 2, 'dungdv', '123456', 'Đỗ Văn Dũng', 'Dũng Kana', 'dung@gmail.com', '789123456', '1983-10-08', 1, 'abcxyz4'),
(10, 1, 'minh2209', 'c60d3011643baad8df7ec5d5217aece6781bc91f', 'minh nhat', 'nhat Kana', 'minh32nt@gmail', '6565475', '1958-10-02', 0, 'eHKrSKrUZSZVnODSStEFUrVqICzWSzuDvaFuFDXCBfzEeDkLJfndOcREfwixavsTlAOQpQclincbSuXjXOiywEBtoMRGoHCTfoQRBoQJJsbOlciYHxwQkLpGxOZMzrGgOsIVyIZrxcpBpfrFFxqTDdBaCVmUCzDlUdlAcZBibgZMmpgANSETJCZqNiHDQHMvjmsWvACLpXIHuVchEMdIenVIcNcjmYDwzpEfXnWBpqdCcbfMVSGeZvRXShDtcpD'),
(12, 2, 'nam123', '123', 'thanh nam\\_', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(13, 2, 'nam123', '123', 'thanh nam\\', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(14, 2, 'nam123', '123', 'thanh nam%', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(15, 2, 'nam123', '123', 'thanh hieu', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(16, 2, 'nam123', '123', 'thanh nam', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(17, 2, 'nam123', '123', 'thanh nam', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(18, 3, 'nam123', '123', 'thanh nam', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(19, 3, 'nam123', '123', 'thanh nam', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(20, 3, 'nam123', '123', 'thanh nam', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(23, 3, 'duyanh3', '123', 'anh duy', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(35, 3, 'zozo123', '123', 'zoko la ko', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(36, 3, 'zozo123', '123', 'user name 12', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(37, 3, 'zozo123', '123', 'user name ', 'nam Kana', 'nam@gmail.com', '123467', '1995-10-11', 1, 'abcde'),
(38, 1, 'yoyo123', '123', 'user name 1', 'name kana', 'yoyo@gmail.com', '123456', '1995-12-10', 1, 'adfg'),
(40, 1, 'minhnrnr', '321123', 'nhat minh minh', 'minh kana', 'minh@gmail.com', '123321', '1996-12-10', 1, 'abcd'),
(47, 1, 'minhnhnh', '8b17c90fba0a12f63b80f2fa5beb8005f3a1d0e5', 'nhat hoài', '', 'minhnh@gmail.com', '123-123-123', '2011-07-23', 1, '1574732303985'),
(48, 1, 'minhadasd', 'ef3b7aa736a59c2390001755cf4dbd892d7d6593', 'nhat hoai', '', 'qwerty@gmail.com', '321-321-321', '1979-06-22', 1, '1574732498742'),
(52, 1, 'tuty123', 'fc75aaf0efb14477b4c4cef8c16853637196b2cf', 'tutut', '', 'tutu@gmail.com', '123-123-1', '2014-10-24', 1, '1574734295403'),
(57, 2, 'thuyym', '625a06e354150e91a8e4f776ecf40243132db2cb', 'thuythuy', '', 'thuythuy@gmail.com', '123-321-1', '2013-09-24', 1, '1574735353615'),
(59, 2, 'thuyrty', 'bb82d3df90ef9efe16b05e94e7aa15ba042eb0fb', 'thuy thuy', '', 'thuyminh@gmail.com', '123-1-1', '2019-11-26', 1, '1574735816663'),
(60, 1, 'thuytrrrrrr', '0c02e1fb3c0bf62ad716b4ddfacb345a614ae60f', 'thuytrrrr', '', 'thur@gmail.com', '123-1-1', '2015-11-26', 1, '1574735890437'),
(66, 1, 'tesCase', '86713e3e5499d3515321ccbca35f84a6fb8048a3', 'test test ', '', 'testmiss@gmail.com', '123-123-1', '2019-11-26', 1, '1574742428707'),
(67, 2, 'vbnvbn', '2bfbbe41a656889e0a7f165f34edd4344e7f46ef', 'vbn', '', 'vbn@gmail.com', '1-1-1', '2019-11-26', 1, '1574743796115'),
(68, 4, 'bmbnm', '51d410ea8059a2ecedeca639dc7d212fffea5551', 'Duy Anh 123', '', 'bnm@gmail.com', '31-13-12', '2001-11-26', 1, '1574744127094'),
(70, 1, 'minhzxcxzc', '441b6ec59339eb4c4771693c4e86a9abaf668ce3', 'zxczxc', '', 'zxcxzc@gmail.com', '123-123-1', '2019-11-27', 1, '1574817927433'),
(71, 2, 'vbvcb', '7c12496f4d93e396655a075530ea32f4d2eb8dbc', 'xcvbcvc', '', 'zxcv@gmail.com', '123-1-1', '2019-11-27', 1, '1574820537312'),
(72, 2, 'mnbmbn', 'eb941daa12fa9e12099a726304b2c975706e1442', 'testCase', '', 'testCase111@gmail.com', '12-12-12', '2019-11-27', 1, '1574820733350'),
(75, 1, 'iyyuiyu', '5ed594f46910b49caff1bd8601e5a9fd5e8a7a26', 'yuiyu', '', 'plhlh@gmail.com', '12-12-1', '2019-11-29', 1, '1574991205670'),
(76, 1, 'uououp', '8f0899420e374be09c8ac13ed4504562507bea52', 'uiouio', '', 'uioui@gmail.com', '12-12-1', '2019-11-29', 1, '1574992148938'),
(77, 2, 'thanhnam13', '59956af1702c57dd26aef925964770437ed91f7a', 'Thanh Nam Cao ', '', 'thanhnam@gmail.com', '12-12-1', '2001-02-03', 1, '1575335610158'),
(78, 1, 'minhkt', '92311b9084aee51c308001c3816fe3d9c15ad807', 'xcvxcvxcvxcvxcvxvxvxc', '', 'minhn22h@gmail.com', '12-12-12', '2009-02-20', 1, '1575349384040'),
(79, 2, 'aaaaaaa12', 'aab8510d1e750364acee73d3dbb1c2449bd4e66f', 'Nguyen Thi Hoai', '', 'phuong@gmail.com', '1234-1234-1234', '2019-12-23', 1, '1577041896292'),
(80, 3, 'aaaaaa', '261e6879da9bd446cbc8c2fa7f49d4bed90b296d', 'Hoàng Nam', '', 'nam23@gmail.com', '23-32-3', '2019-12-23', 1, '1577041977894'),
(81, 2, 'aaaaaaa123', '87e06d40f64cfd86983bafa13d9f5c348d01e52e', 'Nguyen Thi Hoai', '', 'sf.jfd@lfk.lfd', '3-2-3', '2019-12-23', 1, '1577042854633'),
(82, 2, 'aaaaaaa1232', 'b995cc8335753f09743ab043e858d5514585a7ec', 'Nguyen Thi Hoai', '', 'hoai@gmail.com', '1234-1234-1234', '2019-12-23', 1, '1577043768186'),
(83, 2, 'kai123', '13c0dcf28d0267703814e92b4e7aed8236ef9b3e', 'Nguyen Quang Anh12', '', 'tranmaianh20000@gmail.com', '123-456-789', '2021-09-30', 1, '1633019929363'),
(84, 1, 'ntmhuong111', '123456', 'Nguyen Ngoc Thanh', '', 'tranmaianh1120000@gmail.com', '0389-1775-6811', '2021-10-11', 1, '1633922349996'),
(85, 1, 'anhnq12', '4549ebba99992bae773d93e0bc45e8f80434d66a', 'Nguyen Quang Anh', '', 'ginnguyenfb@gmail.com', '0389-1775-6811', '2021-10-11', 1, '1633927843811');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `mst_group`
--
ALTER TABLE `mst_group`
  ADD PRIMARY KEY (`group_id`);

--
-- Chỉ mục cho bảng `mst_japan`
--
ALTER TABLE `mst_japan`
  ADD PRIMARY KEY (`code_level`);

--
-- Chỉ mục cho bảng `tbl_detail_user_japan`
--
ALTER TABLE `tbl_detail_user_japan`
  ADD PRIMARY KEY (`detail_user_japan_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `code_level` (`code_level`);

--
-- Chỉ mục cho bảng `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `group_id` (`group_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `mst_group`
--
ALTER TABLE `mst_group`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `tbl_detail_user_japan`
--
ALTER TABLE `tbl_detail_user_japan`
  MODIFY `detail_user_japan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT cho bảng `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `tbl_detail_user_japan`
--
ALTER TABLE `tbl_detail_user_japan`
  ADD CONSTRAINT `tbl_detail_user_japan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`user_id`),
  ADD CONSTRAINT `tbl_detail_user_japan_ibfk_2` FOREIGN KEY (`code_level`) REFERENCES `mst_japan` (`code_level`);

--
-- Các ràng buộc cho bảng `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `mst_group` (`group_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
