/**
 * Xử lý ẩn hiện vùng trình độ tiếng Nhật
 */
function hideChange() {
	var japan = document.getElementsByClassName("japan");
	for (var i = 0; i < japan.length; i++) {
		if (japan[i].style.display === "none") {
			japan[i].style.display = "table-row"
		} else {
			japan[i].style.display = "none"
		}
	}
}
/**
 * Xử lý js khi click button Xoá
 * 
 * @param action:
 *            đường dẫn url
 * @param userId:
 *            id của user cần xoá
 * @param messageMSG004:
 *            thông báo trên hộp thoại alert
 */
function deleteConfirm(action, userId, messageMSG004) {
	if (window.confirm(messageMSG004)) {
		var deleteForm = document.createElement("form");
		deleteForm.setAttribute("method", "post");
		deleteForm.setAttribute("action", action);
		var input = document.createElement("input");
		input.setAttribute("type", "hidden");
		input.setAttribute("name", "userId");
		input.setAttribute("value", userId);
		deleteForm.appendChild(input);
		document.body.appendChild(deleteForm);
		deleteForm.submit();
	}
}