/**
 * copy right luvina
 */
package manageuser.logics;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import manageuser.entities.MstGroupBean;

/**
 * Interface MstGroupLogic
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public interface MstGroupLogic {
	/**
	 * Hàm lấy ra tất cả group trong bảng MstGroup trong DB
	 * 
	 * @return listMstgroup danh sách group trong DB
	 * @throws ClassNotFoundException bắn lỗi khi không tìm thấy driver
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 */
	List<MstGroupBean> getAllMstGroup() throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy tên groupName theo groupId truyền vào
	 * 
	 * @param groupId mã group
	 * @return groupName tương ứng với groupId
	 * @throws ClassNotFoundException bắn lỗi khi không tìm thấy driver
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 */
	MstGroupBean getMstGroupById(int groupId) throws ClassNotFoundException, SQLException;

	/**
	 * Kiểm tra xem group có tồn tại trong DB hay không
	 * 
	 * @param groupId mã group
	 * @return false nếu group tồn tại trong DB, true nếu group không tồn tại
	 * @throws ClassNotFoundException bắn lỗi khi không tìm thấy driver
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 */
	boolean checkExistGroupName(int groupId) throws ClassNotFoundException, SQLException, IOException;

}
