/**
 * copy right luvina
 */
package manageuser.logics;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import manageuser.entities.UserInfo;

/**
 * @author NGUYEN QUANG ANH
 * 
 *
 */
public interface TblUserLogic {
	/**
	 * Hàm kiểm tra xem tên đăng nhập và mật khẩu có tồn tại không
	 * 
	 * @param user tên đăng nhập
	 * @param pass mật khẩu
	 * @return true nếu tên đăng nhập và mật khẩu tồn tại, false nếu ngược lại
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 */
	public boolean checkExitAdmin(String user, String pass)
			throws ClassNotFoundException, SQLException, NoSuchAlgorithmException;

	/**
	 * Lấy ra danh sách User
	 * 
	 * @param offset          vị trí data cần lấy
	 * @param limit           số lượng lấy
	 * @param groupId         mã nhóm tìm kiếm
	 * @param fullName        tên tìm kiếm
	 * @param sortType        sắp xếp theo trường nào(full_name or code_level or
	 *                        end_date)
	 * @param sortByFullName  Giá trị sắp xếp của cột Tên(ASC or DESC)
	 * @param sortByCodeLevel Giá trị sắp xếp của cột Trình độ tiếng nhật(ASC or
	 *                        DESC)
	 * @param sortByEndDate   Giá trị sắp xếp của cột Ngày kết hạn(ASC or DESC)
	 * @return List<UserInfo> Danh sách User lấy được
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public List<UserInfo> getListUser(int offset, int limit, int groupID, String fullName, String softType,
			String softByFullName, String softByCodeLevel, String softByEnddate)
			throws ClassNotFoundException, SQLException;

	/**
	 * Lấy tổng số user
	 * 
	 * @param groupId  mã nhóm tìm kiếm
	 * @param fullName tên tìm kiếm
	 * @return tổng số user (int)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public int getTotalUser(int groupId, String fullName) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm kiểm tra xem login loginName truyền vào có tồn tại trong DB hay không
	 * 
	 * @param loginName
	 * @return true nếu loginName có tồn tại trong DB, false nếu LoginName không tồn
	 *         tại trong DB
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public boolean checkExistLoginName(String loginName) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm kiểm tra xem email truyền vào có tồn tại trong DB hay không
	 * 
	 * @param email
	 * @return true nếu email truyền vào tồn tại trong DB, false nếu email truyền
	 *         vào không tồn tại trong DB
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public boolean checkExistEmail(String email, int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm thêm mới 1 user từ userInfor
	 * 
	 * @param userInfor
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public void createUser(UserInfo userInfor) throws ClassNotFoundException, SQLException, NoSuchAlgorithmException;

	/**
	 * Hàm kiểm tra xem id đã tồn tại trong database chưa
	 * 
	 * @param userId
	 * @return true nếu id đã tồn tại, false nếu id chưa tồn tại
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public boolean checkExitUserId(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy ra đối tượng userInfor theo userId truyền vào
	 * 
	 * @param userId
	 * @return userInfor
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public UserInfo getUserInforById(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm edit 1 user
	 * 
	 * @param userInfor
	 * @param check
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public void editUser(UserInfo userInfor, boolean check)
			throws ClassNotFoundException, SQLException, IOException, NoSuchAlgorithmException;

	/**
	 * Hàm lấy ra message khi thực hiện tìm kiếm rule theo userId truyền vào
	 * 
	 * @param userId
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public String getMessageRuleUserId(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm delete 1 user
	 * 
	 * @param userId
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public void deleteUserInfor(int userId) throws ClassNotFoundException, SQLException;
}
