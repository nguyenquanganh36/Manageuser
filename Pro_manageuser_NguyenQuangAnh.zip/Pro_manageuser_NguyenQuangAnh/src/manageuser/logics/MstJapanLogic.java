/**
 * copy right luvina
 */
package manageuser.logics;

import java.sql.SQLException;
import java.util.List;

import manageuser.entities.MstJapanBean;

/**
 * Interface MstJapanLogic
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public interface MstJapanLogic {
	/**
	 * Hàm lấy ra danh sách tất cả trình độ tiếng nhật trong DB
	 * 
	 * @return danh sách trình độ tiếng nhật trong DB
	 * @throws ClassNotFoundException bắn lỗi khi không tìm thấy driver
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 */
	List<MstJapanBean> getAllMstJapan() throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy ra nameLevel theo codeLevel truyền vào
	 * 
	 * @param codeLevel mã trình độ tiếng Nhật
	 * @return nameLevel tương ứng với codeLevel nếu có
	 * @throws ClassNotFoundException bắn lỗi khi không tìm thấy driver
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 */
	String getNameLevelByCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm check codeLevel có tồn tại trong DB không
	 * 
	 * @param codeLevel mã trình độ tiếng Nhật
	 * @return true nếu tồn tại ,false nếu không tồn tại
	 * @throws ClassNotFoundException bắn lỗi khi không tìm thấy driver
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 */
	boolean checkExistCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException;
}
