/**
 * copy right luvina
 */
package manageuser.logics.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import manageuser.dao.MstJapanDao;
import manageuser.dao.impl.MstJapanDaoImpl;
import manageuser.entities.MstJapanBean;
import manageuser.logics.MstJapanLogic;

/**
 * Lớp xử lý logic
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class MstJapanLogicImpl implements MstJapanLogic {

	@Override
	public List<MstJapanBean> getAllMstJapan() throws ClassNotFoundException, SQLException {
		// Khởi tạo danh sách chứa MstJapan
		List<MstJapanBean> listMstjapan = new ArrayList<MstJapanBean>();
		// Khởi tạo đối tượng MstJapanDaoImpl
		MstJapanDao mstJapanDaoImpl = new MstJapanDaoImpl();
		try {
			listMstjapan = mstJapanDaoImpl.getAllMstJapan();
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi log lại
			System.out.println("MstJapanLogicImpl : getAllMstJapan" + e.getMessage());
			throw e;
		}
		return listMstjapan;
	}

	@Override
	public String getNameLevelByCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException{
		MstJapanDao mstJapanDaoImpl = new MstJapanDaoImpl();
		return mstJapanDaoImpl.getNameLevelByCodeLevel(codeLevel);
	}

	@Override
	public boolean checkExistCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException{
		boolean check = false;
		MstJapanDao mstJapanDaoImpl = new MstJapanDaoImpl();
		MstJapanBean mstJapan = mstJapanDaoImpl.getMstJapanByCodeLevel(codeLevel);
		if(mstJapan!=null) {
			check = true;
		}
		return check;
	}

}
