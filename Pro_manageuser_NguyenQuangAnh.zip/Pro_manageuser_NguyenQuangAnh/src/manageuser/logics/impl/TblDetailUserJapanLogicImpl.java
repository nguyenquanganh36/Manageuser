/**
 * copy right luvina
 */
package manageuser.logics.impl;

import java.sql.SQLException;

import manageuser.dao.TblDetailUserJapanDao;
import manageuser.dao.impl.TblDetailUserJapanDaoImpl;
import manageuser.entities.TbldetailUserJapanBean;
import manageuser.entities.UserInfo;
import manageuser.logics.TblDetailUserJapanLogic;
import manageuser.utils.Common;

/**
 * Hàm xử lý logic liên quan đến đối tượng tbldetailUserJapan
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class TblDetailUserJapanLogicImpl implements TblDetailUserJapanLogic {

	@Override
	public TbldetailUserJapanBean createTblDetailUserJapanForUserInfor(UserInfo userInfor, int userId)
			throws ClassNotFoundException, SQLException {
		// Khởi tạo 1 TbldetailUserJapanBean
		TbldetailUserJapanBean tbldetailUserJapanBean = new TbldetailUserJapanBean();
		// chuyển dạng startDate từ yyyy/mm/dd thành yyyy-mm-dd
		String startDate = Common.changeToDateType(userInfor.getStartDate());
		// chuyển dạng endDate từ yyyy/mm/dd thành yyyy-mm-dd
		String endDate = Common.changeToDateType(userInfor.getEndDate());
		// set các giá trị cho đối tượng tbldetailUserJapanBean
		tbldetailUserJapanBean.setUserId(userId);
		tbldetailUserJapanBean.setCodeLevel(userInfor.getCodeLevel());
		tbldetailUserJapanBean.setStartDate(startDate);
		tbldetailUserJapanBean.setEndDate(endDate);
		tbldetailUserJapanBean.setTotal(userInfor.getTotal());
		// Trả về một đối tượng tbldetailUserJapanBean

		return tbldetailUserJapanBean;
	}

	@Override
	public boolean checkExitDetailUserJapan(int userId) throws ClassNotFoundException, SQLException{
		// Tạo một biến check
		boolean checkExitDetailUserJapan = false;
		// Khởi tạo đối tượng TblDetailUserJapan
		TblDetailUserJapanDao TblDetailUserJapanDaoImpl = new TblDetailUserJapanDaoImpl();
		// Khởi tạo đối tượng
		TbldetailUserJapanBean tbldetailUserJapanBean = TblDetailUserJapanDaoImpl.getTblDetailUserJapan(userId);
		if (tbldetailUserJapanBean != null) {
			checkExitDetailUserJapan = true;
		}
		return checkExitDetailUserJapan;
	}

}
