/**
 * copy right luvina
 */
package manageuser.logics.impl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import manageuser.dao.MstGroupDao;
import manageuser.dao.impl.MstGroupDaoImpl;
import manageuser.entities.MstGroupBean;
import manageuser.logics.MstGroupLogic;

/**
 * Lớp thực thi interface MstGroupLogic để xử lý logic
 * 
 * @author NGUYỄN QUANG ANH
 *
 */
public class MstGroupLogicImpl implements MstGroupLogic {

	@Override
	public List<MstGroupBean> getAllMstGroup() throws ClassNotFoundException, SQLException {
		List<MstGroupBean> listGroup = new ArrayList<MstGroupBean>();
		// khoi tao doi tuong mstgroupimpl
		MstGroupDao mstGroupDaoImpl = new MstGroupDaoImpl();
		try {
			listGroup = mstGroupDaoImpl.getAllMstGroup();
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("MstGroupLogicImpl: getAllMstGroup: " + e.getMessage());
			throw e;
		}
		return listGroup;
	}

	@Override
	public MstGroupBean getMstGroupById(int groupId) throws ClassNotFoundException, SQLException {
		// Khởi tạo đối tượng MstGroupDaoImpl
		MstGroupDao mstGroupDaoImpl = new MstGroupDaoImpl();
		MstGroupBean mstGroup = null;
		try {
			// Trả về tên groupName theo groupId truyền vào
			mstGroup = mstGroupDaoImpl.getMstGroupById(groupId);
		} catch (SQLException e) {
			// Ghi log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			throw e;
		}
		return mstGroup;
	}

	@Override
	public boolean checkExistGroupName(int groupId) throws ClassNotFoundException, SQLException, IOException {
		boolean check = true;
		// Khởi tạo đối tượng MstGroupDaoImpl
		MstGroupDao mstGroupDaoImpl = new MstGroupDaoImpl();
		MstGroupBean mstGroup = null;
		try {
			// Trả về mstgroup theo groupId truyền vào
			mstGroup = mstGroupDaoImpl.getMstGroupById(groupId);
			if (mstGroup != null) {
				check = false;
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			throw e;
		}
		return check;
		// Hàm này trả về true nếu groupName lấy về theo groupId ko tồn tại
		// trong DB, false nếu groupName tồn tại trong DB
	}

}
