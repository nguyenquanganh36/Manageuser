/**
 * copy right luvina
 */
package manageuser.logics.impl;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import manageuser.dao.TblDetailUserJapanDao;
import manageuser.dao.TblUserDao;
import manageuser.dao.impl.TblDetailUserJapanDaoImpl;
import manageuser.dao.impl.TblUserDaoImpl;
import manageuser.entities.TblUserBean;
import manageuser.entities.TbldetailUserJapanBean;
import manageuser.entities.UserInfo;
import manageuser.logics.TblDetailUserJapanLogic;
import manageuser.logics.TblUserLogic;
import manageuser.utils.Common;
import manageuser.utils.Constant;

/**
 * Lớp xử lí logic
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class TblUserLogicImpl implements TblUserLogic {

	@Override
	public boolean checkExitAdmin(String loginName, String passWord)
			throws ClassNotFoundException, SQLException, NoSuchAlgorithmException{
		boolean check = false;
		try {
			TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
			TblUserBean userLogin = tblUserDaoImpl.getUserByLoginName(loginName);
			if (userLogin != null) {
				// Ma hoa SHA1
				String endcodePassword = Common.encryptSHA1(passWord, userLogin.getSalt());
				// so sánh chuỗi mã hóa với password lấy ra từ DB
				check = Common.compareString(userLogin.getPassword(), endcodePassword);
			}
		} catch (ClassNotFoundException | SQLException | NoSuchAlgorithmException e) {
			// ghi lại log
			System.out.println("TblUserLogicImpl : checkExitAdmin " + e.getMessage());
			// throw cho hàm gọi đến nó xử lí
			throw e;
		}
		return check;
	}

	@Override
	public List<UserInfo> getListUser(int offset, int limit, int groupID, String fullName, String softType,
			String softByFullName, String softByCodeLevel, String softByEnddate)
			throws ClassNotFoundException, SQLException{
		List<UserInfo> listUserInfor = new ArrayList<UserInfo>();
		try {
			// Khởi tạo đối tượng
			TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
			fullName = Common.replaceWildCard(fullName);
			listUserInfor = tblUserDaoImpl.getListUser(offset, limit, groupID, fullName, softType, softByFullName,
					softByCodeLevel, softByEnddate);
		} catch (ClassNotFoundException | SQLException e) {
			// ghi log lại
			System.out.println("TblUserLogicImpl: getListUser: " + e.getMessage());
			// throw cho hàm gọi đến nó xử lí
			throw e;
		}
		return listUserInfor;
	}

	@Override
	public int getTotalUser(int groupId, String fullName) throws ClassNotFoundException, SQLException{
		int totalUser = 0;
		// Khởi tạo đối tượng tblUserDaoImpl
		TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
		fullName = Common.replaceWildCard(fullName);
		totalUser = tblUserDaoImpl.getTotalUser(groupId, fullName);
		return totalUser;
	}

	@Override
	public boolean checkExistLoginName(String loginName) throws ClassNotFoundException, SQLException{
		// Tạo một biến check existLoginName
		boolean checkLoginName = false;
		TblUserBean TblUserBean = null;
		try {
			TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
			TblUserBean = tblUserDaoImpl.getUserByLoginName(loginName);
			if (TblUserBean != null) {
				checkLoginName = true;
			}
		} catch (SQLException e) {
			// TODO: handle exception
		}

		return checkLoginName;
	}

	@Override
	public boolean checkExistEmail(String email, int userId) throws ClassNotFoundException, SQLException{
		boolean checkEmail = false;
		TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
		TblUserBean tblUser = null;
		tblUser = tblUserDaoImpl.getTblUserByEmail(email, userId);
		if (tblUser != null) {
			checkEmail = true;
		}
		return checkEmail;
	}

	@Override
	public void createUser(UserInfo userInfor)
			throws ClassNotFoundException, SQLException, NoSuchAlgorithmException {
		// Khởi tạo đối tượng TblUserDaoImpl
		TblUserDao TblUserDaoImpl = new TblUserDaoImpl();
		// Khởi tạo đối tượng TblDetailUserJapanDaoImpl
		TblDetailUserJapanDao TblDetailUserJapanImpl = new TblDetailUserJapanDaoImpl();
		// Khởi tạo đối tượng connection
		Connection conn = null;
		try {
			// Lấy connection
			conn = TblUserDaoImpl.getConnection();
			if (conn != null) {
				// set ko cho tự động commit
				conn.setAutoCommit(false);
				// Tạo một đối tượng TblUser từ UserInfor
				TblUserBean tblUser = new TblUserBean();
				tblUser = createTblUserForUserInfor(userInfor);
				// Ghi tblUser vào DB
				int userId = TblUserDaoImpl.insertTblUser(tblUser);
				// Nếu thêm mới tblUser thành công
				if (userId > 0) {
					// Nếu có chọn trình độ tiếng Nhật
					if (!"0".equals(userInfor.getCodeLevel())) {
						// set chung 1 connection
						TblDetailUserJapanImpl.setConnection(conn);
						TbldetailUserJapanBean tblDetailUserJapanBean = new TbldetailUserJapanBean();
						TblDetailUserJapanLogic tblDetailUserJapanLogicImpl = new TblDetailUserJapanLogicImpl();
						// Tạo một đối tượng TblDetailUserJapanBean từ UserInfor
						tblDetailUserJapanBean = tblDetailUserJapanLogicImpl
								.createTblDetailUserJapanForUserInfor(userInfor, userId);
						// Ghi TblDetailUserJapan vào DB
						TblDetailUserJapanImpl.insertDetailUserJapan(tblDetailUserJapanBean);
					}
				}
			}
			conn.commit();
		} catch (ClassNotFoundException | SQLException | NoSuchAlgorithmException e) {
			conn.rollback();
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			conn.close();
		}
	}

	/**
	 * Hàm tạo ra 1 TblUser từ userInfor
	 * 
	 * @param userInfor
	 * @return tblUser 1 đối tượng tblUser
	 * @throws NoSuchAlgorithmException
	 */
	private TblUserBean createTblUserForUserInfor(UserInfo userInfor) throws NoSuchAlgorithmException {
		// Tạo ra 1 salt
		String salt = Common.getkey();
		// chuyển dạng birthday từ yyyy/mm/dd thành yyyy-mm-dd
		String birthDay = Common.changeToDateType(userInfor.getBirthday());
		// mã hóa mật khẩu
		String pass = Common.encryptSHA1(userInfor.getPass(), salt);
		// Khởi tạo đối tượng TblUser
		TblUserBean tblUser = new TblUserBean();
		// set các giá trị cho đối tượng TblUser
		tblUser.setUserId(userInfor.getUserId());
		tblUser.setGroupId(userInfor.getGroupId());
		tblUser.setLoginName(userInfor.getLoginName());
		tblUser.setFullName(userInfor.getFullName());
		tblUser.setFullNameKana(userInfor.getFullNameKana());
		tblUser.setTel(userInfor.getTel());
		tblUser.setBirthday(birthDay);
		tblUser.setEmail(userInfor.getEmail());
		tblUser.setPassword(pass);
		tblUser.setRule(1);
		tblUser.setSalt(salt);
		// Trả về đối tượng tblUser
		return tblUser;
	}

	@Override
	public boolean checkExitUserId(int userId) throws ClassNotFoundException, SQLException {
		// Khởi tạo đối tượng tblUserdaoimpl
		TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
		boolean check = false;
		if (tblUserDaoImpl.getTblUserById(userId) != null) {
			check = true;
		}
		return check;
	}

	@Override
	public UserInfo getUserInforById(int userId) throws ClassNotFoundException, SQLException{
		// Khởi tạo đối tượng userInfor
		UserInfo userInfor = new UserInfo();
		// Khởi tạo đối tượng tblUserDaoImpl
		TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
		userInfor = tblUserDaoImpl.getUserInforById(userId);
		// Trả về 1 đối tượng userInfor
		return userInfor;
	}

	@Override
	public void editUser(UserInfo userInfor, boolean check)
			throws ClassNotFoundException, SQLException, NoSuchAlgorithmException {
		// Khởi tạo đối tượng TblUserDaoImpl
		TblUserDao TblUserDaoImpl = new TblUserDaoImpl();
		// Khởi tạo đối tượng TblDetailUserJapanDaoImpl
		TblDetailUserJapanDao TblDetailUserJapanImpl = new TblDetailUserJapanDaoImpl();
		// Khởi tạo đối tượng connection
		Connection conn = null;
		try {
			// Lấy ra connection
			conn = TblUserDaoImpl.getConnection();
			if (conn != null) {
				// set không cho tự động commit
				conn.setAutoCommit(false);
				// Lấy userId của userInfor
				int userId = userInfor.getUserId();
				// Tạo một đối tượng TblUser từ UserInfor
				TblUserBean tblUser = new TblUserBean();
				tblUser = createTblUserForUserInfor(userInfor);
				TblUserDaoImpl.editTblUser(tblUser);
				// set chung một connection
				TblDetailUserJapanImpl.setConnection(conn);
				// Tạo một đối tượng tbldetailUserJapan từ userInfor
				TbldetailUserJapanBean tbldetailUserJapan = new TbldetailUserJapanBean();
				// Khởi tạo đối tượng tblDetailUserJapanLogicImpl
				TblDetailUserJapanLogic tblDetailUserJapanLogicImpl = new TblDetailUserJapanLogicImpl();
				// Phân thành 3 trường hợp:
				// 1.Người dùng chọn trình độ tiếng Nhật và bản ghi trong DB
				// đã có trình độ tiếng Nhật => Edit
				// 2.Người dùng chọn trình độ tiếng Nhật và bản ghi trong DB
				// chưa có trình độ tiếng Nhật => Insert
				// 3.Người dùng không chọn trình độ tiếng Nhật và bản ghi
				// trong DB có trình độ tiếng Nhật => Delete

				// Nếu người dùng chọn trình độ tiếng Nhật
				if (!"0".equals(userInfor.getCodeLevel())) {
					tbldetailUserJapan = tblDetailUserJapanLogicImpl.createTblDetailUserJapanForUserInfor(userInfor,
							userId);
					// Nếu trong DB cũng đang có trình độ tiếng Nhật
					if (check) {
						// Thực hiện edit
						TblDetailUserJapanImpl.editTblDetailUserJapan(tbldetailUserJapan);
						// Nếu trong DB không có trình độ tiếng Nhật
					} else {
						// Thực hiện insert
						TblDetailUserJapanImpl.insertDetailUserJapan(tbldetailUserJapan);
					}
					// Nếu người dùng không chọn trình độ tiếng Nhật và
					// trong DB đang có trình độ tiếng Nhật
				} else if ("0".equals(userInfor.getCodeLevel()) && check) {
					// Thực hiện delete
					TblDetailUserJapanImpl.deleteTblDetailUserJapan(userId);
				}
				conn.commit();
			}
		} catch (ClassNotFoundException | SQLException | NoSuchAlgorithmException e) {
			// Nếu edit không thành công thì thực hiện rollback, trả lại trạng
			// thái ban đầu trước khi edit cho DB
			conn.rollback();
			// Ghi log lại
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			conn.close();
		}
	}

	@Override
	public String getMessageRuleUserId(int userId) throws ClassNotFoundException, SQLException{
		// Tạo biến String
		String message = "";
		// Khởi tạo đối tượng TblUserDaoImpl
		TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
		String result = tblUserDaoImpl.getRuleUserById(userId);
		if ("0".equals(result)) {
			message = Constant.ER020;
		} else if ("1".equals(result)) {
			message = "";
		} else {
			message = Constant.ER013;
		}
		return message;
	}

	@Override
	public void deleteUserInfor(int userId) throws ClassNotFoundException, SQLException{
		// Khởi tạo đối tượng TblUserDaoImpl
		TblUserDao tblUserDaoImpl = new TblUserDaoImpl();
		// Khởi tạo đối tượng TblDetailUserJapanDaoImpl
		TblDetailUserJapanDao tblDetailUserJapanDaoImpl = new TblDetailUserJapanDaoImpl();
		// Khởi tạo connection
		Connection conn = null;
		try {
			conn = tblUserDaoImpl.getConnection();
			if (conn != null) {
				// set tự động commit là fasle
				conn.setAutoCommit(false);
				// set chung 1 connection
				tblDetailUserJapanDaoImpl.setConnection(conn);
				// Thực hiện xoá trình độ tiếng Nhật
				tblDetailUserJapanDaoImpl.deleteTblDetailUserJapan(userId);
				// Thực hiện xoá luôn TblUser
				tblUserDaoImpl.deleteUser(userId);
				conn.commit();
			}
		} catch (Exception e) {
			conn.rollback();
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			// Đóng kết nối
			conn.close();
		}
	}

}
