/**
 * copy right luvina
 */
package manageuser.logics;

import java.sql.SQLException;
import manageuser.entities.TbldetailUserJapanBean;
import manageuser.entities.UserInfo;

/**
 * @author NGUYEN QUANG ANH
 *
 */
public interface TblDetailUserJapanLogic {
	/**
	 * Tạo một đối tượng TblDetailUserJapan từ một UserInfo và một userId
	 * @param userInfor đối tượng UserInfo
	 * @param userId
	 * @return TbldetailUserJapanBean đối tượng TblDetailUserJapan
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public TbldetailUserJapanBean createTblDetailUserJapanForUserInfor(UserInfo userInfor, int userId)
			throws ClassNotFoundException, SQLException;

	/**
	 * Kiểm tra xem user đã có trình độ tiếng Nhật theo userId truyền vào hay chưa
	 * @param userId
	 * @return true nếu tồn tại, false nếu không tồn tại
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public boolean checkExitDetailUserJapan(int userId) throws ClassNotFoundException, SQLException;
}
