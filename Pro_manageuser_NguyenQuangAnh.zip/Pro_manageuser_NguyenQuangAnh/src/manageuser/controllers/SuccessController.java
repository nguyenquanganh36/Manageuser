/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import manageuser.properties.Messageproperties;
import manageuser.utils.Constant;

/**
 * Controller xử lý cho MH ADM006 
 * @author NGUYEN QUANG ANH
 *
 */
public class SuccessController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Lấy về typeMessage trên request
		String typeMessage = req.getParameter(Constant.TYPE_MESSAGE);
		// Khởi tạo câu thông báo
		String message = Constant.EMPTY;
		switch (typeMessage) {
		case Constant.MSG001:
			message = Messageproperties.getValueByKey(Constant.MSG001);
			break;
		case Constant.MSG002:
			message = Messageproperties.getValueByKey(Constant.MSG002);
			break;
		case Constant.MSG003:
			message = Messageproperties.getValueByKey(Constant.MSG003);
			break;
		default:
			break;
		}
		// Set câu thông báo lên request
		req.setAttribute(Constant.MESSAGE, message);
		// forward ra màn hình ADM006
		req.getRequestDispatcher(Constant.JSP_ADM006).forward(req, resp);
	}
}
