/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import manageuser.properties.ErrorMessageProperties;
import manageuser.utils.Constant;

/**
 * Controller xử lý cho màn hình thông báo lỗi
 * @author NGUYEN QUANG ANH
 *
 */
public class SystemErrorController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
//			Lấy về typeMessage trên request
			String typeMessage = req.getParameter(Constant.TYPE_MESSAGE);
//			Khởi tạo câu thông báo 
			String errorMessage = Constant.EMPTY;
			switch (typeMessage) {
			case Constant.ER013:
				errorMessage = ErrorMessageProperties.getValueByKey(Constant.ER013);
				break;
			case Constant.ER020:
				errorMessage = ErrorMessageProperties.getValueByKey(Constant.ER020);
				break;
			case Constant.ER015:
				errorMessage = ErrorMessageProperties.getValueByKey(Constant.ER015);
				break;
			default:
				break;
			}
//			set câu thông báo lên request
			req.setAttribute(Constant.ERROR_MESSAGE, errorMessage);
//			Chuyển hướng sang màn hình lỗi 
			req.getRequestDispatcher(Constant.JSP_SYSTEM_ERRPOR).forward(req, resp);
		} catch (Exception e) {
//			Ghi lại log
			System.out.println("SystemErrorController : doGet" + e.getMessage());
		}
	}
}
