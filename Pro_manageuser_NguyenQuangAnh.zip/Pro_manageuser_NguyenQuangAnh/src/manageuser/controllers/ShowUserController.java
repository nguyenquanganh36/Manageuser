/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import manageuser.entities.UserInfo;
import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.properties.Messageproperties;
import manageuser.utils.Constant;

/**
 * Controller xử lý cho MH ADM005 show ra thông tin chi tiết của user
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class ShowUserController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Hiển thị thông tin user khi click vào link ID
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Khởi tạo đối tượng userInfor
		UserInfo userInfor = new UserInfo();
		try {
			// Khởi tạo đối tượng tblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
			// Lấy về userId
			int userId = Integer.parseInt(req.getParameter(Constant.USER_ID));
			// Kiểm tra userId đã tồn tại chưa
			if (userId > 0 && tblUserLogicImpl.checkExitUserId(userId)) {
				// Lấy ra userInfor theo userId truyền vào
				userInfor = tblUserLogicImpl.getUserInforById(userId);
				String messageMSG004 = Messageproperties.getValueByKey(Constant.MSG004);
				// set câu message lên request
				req.setAttribute(Constant.MESSAGE_MSG004, messageMSG004);
				// set userInfor lên request
				req.setAttribute(Constant.USER_INFOR, userInfor);
				// chuyển sang màn hình ADM005 để hiển thị
				req.getRequestDispatcher(Constant.JSP_ADM005).forward(req, resp);
			} else {
				// Chuyển hướng ra màn hình systerm error lỗi ER013
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER013);
			}
		} catch (Exception e) {
			// Ghi lại log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển hướng sang màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}
}
