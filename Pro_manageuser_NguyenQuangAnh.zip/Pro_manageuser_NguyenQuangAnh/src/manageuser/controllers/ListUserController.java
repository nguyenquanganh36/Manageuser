/**
  * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.entities.MstGroupBean;
import manageuser.entities.UserInfo;
import manageuser.logics.MstGroupLogic;
import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.MstGroupLogicImpl;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.properties.Messageproperties;
import manageuser.utils.Common;
import manageuser.utils.Constant;

/**
 * Controller xử lý cho màn hình ADM002
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class ListUserController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * Xử lý cho màn hình ADM002
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.
	 * HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// Gán tham số mặc định offset
			int offset = Constant.DELAULT_OFFSET;
			// Gán tham số mặc địnhgroupID
			int groupID = Constant.DEFAULT_GROUP_ID;
			// Gán tham số mặc định fullName
			String fullName = Constant.DEFAULT_FULL_NAME;
			// Gán tham số mặc định sortByFullName
			String softByFullName = Constant.SORT_ASC;
			// Gán tham số mặc định sortByCodeLevel
			String softByCodeLevel = Constant.SORT_ASC;
			// Gán tham số mặc định sortByEndDate
			String softByEnddate = Constant.SORT_DESC;
			// Gán tham số mặc định sortType
			String sortType = Constant.SORT_TYPE_DEFAULT;
			// Gán tham số mặc định sortValue
			String sortValue = Constant.SORT_VALUE_DEFAULT;
			// Gán tham số mặc định currentPage
			int currentPage = Constant.CURRENT_PAGE_DEFAULT;
			// Gán tham số mặc định totalPage
			int totalPage = Constant.TOTAL_PAGE_DEFAULT;

			// Lấy ra session của project
			HttpSession session = request.getSession();

			// khởi tạo đối tượng tblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
			// khởi tạo listUserInfor danh sách user hiển thị
			List<UserInfo> listUserInfor = new ArrayList<UserInfo>();
			// Khởi tạo đối tượng mstGroupLogicImpl
			MstGroupLogic mstGroupLogicImpl = new MstGroupLogicImpl();
			// khởi tạo listMstGroup danh sách nhóm hiển thị
			List<MstGroupBean> listMstGroup = mstGroupLogicImpl.getAllMstGroup();
			// Lấy số bản ghi hiển thị trên 1 trang
			int limit = Common.getLimit();
			// Lấy ra action type từ form
			String type = request.getParameter(Constant.TYPE);
			// Trường hợp Back
			if (Constant.BACK.equals(type)) {
				// Lấy giá trị của các thuộc tính từ session
				// lấy giá trị fullName từ session
				fullName = (String) session.getAttribute(Constant.FULLNAME);
				// lấy giá trị groupId từ session
				groupID = (int) session.getAttribute(Constant.GROUPID);
				// lấy giá trị currentPage từ session
				currentPage = (int) session.getAttribute(Constant.CURRENT_PAGE);
				// lấy giá trị sortType từ session
				sortType = (String) session.getAttribute(Constant.SORT_TYPE);
				// Start fix bug ID 12 – AnhNQ 2019/12/25
				// lấy giá trị sortByFullName từ session
				softByFullName = (String) session.getAttribute(Constant.SOFT_BY_FULL_NAME);
				// lấy giá trị sortByCodeLevel từ session
				softByCodeLevel = (String) session.getAttribute(Constant.SOFT_BY_CODE_LEVEL);
				// lấy giá trị sortByEndDate từ session
				softByEnddate = (String) session.getAttribute(Constant.SOFT_BY_END_DATE);
				// End fix bug ID 12 – AnhNQ 2019/12/25
				// lấy giá trị sortType từ session
				type = (String) session.getAttribute(Constant.TYPE);
				// Trường hợp Search hoặc Sort hoặc Paging
			} else if (Constant.SEARCH.equals(type) || Constant.SORT.equals(type) || Constant.PAGING.equals(type)) {
				// Gán lại giá trị cho fullName lấy từ form
				fullName = request.getParameter(Constant.FULLNAME);
				// Gán lại giá trị cho groupId lấy từ form
				groupID = Common.conVertStringToInt(request.getParameter(Constant.GROUP_ID), Constant.DEFAULT_GROUP_ID);
				// Trường hợp action là Sort hoặc Paging
				if (Constant.SORT.equals(type) || Constant.PAGING.equals(type)) {
					// Gán lại giá trị cho currentPage
					currentPage = Common.conVertStringToInt(request.getParameter(Constant.CURRENT_PAGE),
							Constant.CURRENT_PAGE_DEFAULT);
					// Gán lại giá trị cho sortType
					sortType = request.getParameter(Constant.SORT_TYPE);
					// Gán lại giá trị cho sortValue
					sortValue = request.getParameter(Constant.SORT_VALUE);
					switch (sortType) {
					case Constant.SORT_TYPE_FULLNAME:
						// Gán lại giá trị cho softByFullName
						softByFullName = sortValue;
						break;
					case Constant.SORT_TYPE_CODE_LEVEL:
						// Gán lại giá trị cho softByCodeLevel
						softByCodeLevel = sortValue;
						break;
					case Constant.SORT_TYPE_END_DATE:
						// Gán lại giá trị cho softByEnddate
						softByEnddate = sortValue;
						break;
					default:
						break;
					}
				}
			} else if (Constant.DEFAULT.equals(type)) {
				// trường hợp Default giữ các giá trị mặc định của thuộc tính
			}
			// lấy tổng số user có trong Database
			int totalUser = tblUserLogicImpl.getTotalUser(groupID, fullName);
			// tổng số page tối đa trong 1 nhóm
			int limitPage = Common.getLimitPage();
			// Nếu tổng số user tìm được > 0 thì mới xử lí phần hiển thị và
			// paging
			if (totalUser > 0) {
				// lấy tổng số page hiển thị các bản ghi
				totalPage = Common.getTotalPage(totalUser, limit);
				currentPage = Common.checkCurrentPage(totalPage, currentPage);
				// lấy giá trị vị trí bắt đầu lấy dữ liệu offset
				offset = Common.getOffset(currentPage, limit);
				// lấy về danh sách các user
				listUserInfor = tblUserLogicImpl.getListUser(offset, limit, groupID, fullName, sortType, softByFullName,
						softByCodeLevel, softByEnddate);
				// Lấy về danh sách các page sẽ hiển thị
				List<Integer> listPaging = Common.getListPaging(totalPage, currentPage);
				// set listPaging lên session
				request.setAttribute(Constant.LIST_PAGING, listPaging);
			} else {
				// Xử lý hiển thị câu thông báo không có user nào trên MH ADM002
				// Lấy câu thông báo lỗi từ trong file properties
				String message = Messageproperties.getValueByKey(Constant.MSG005);
				// set thông báo lỗi lên request
				request.setAttribute(Constant.MESSAGE, message);
			}

			// Set dữ liệu lên request để hiển thị trên màn hình ADM002
			// set limmitpage len request
			request.setAttribute(Constant.LIMIT_PAGE, limitPage);
			// set totalPage lên request
			request.setAttribute(Constant.TOTAL_PAGE, totalPage);
			// Set giá trị cho listMstGroup lên request
			request.setAttribute(Constant.LIST_MSTGROUP, listMstGroup);
			// Set giá trị cho listTblUserInfors lên request
			request.setAttribute(Constant.LIST_USER_INFOR, listUserInfor);

			// Set dữ liệu lên session để thực hiện action Back
			// set fullName lên session
			session.setAttribute(Constant.FULLNAME, fullName);
			// set groupId lên session
			session.setAttribute(Constant.GROUPID, groupID);
			// set currentPage lên session
			session.setAttribute(Constant.CURRENT_PAGE, currentPage);
			// set softByFullName lên session
			session.setAttribute(Constant.SOFT_BY_FULL_NAME, softByFullName);
			// set softByCodeLevel lên session
			session.setAttribute(Constant.SOFT_BY_CODE_LEVEL, softByCodeLevel);
			// set softByEnddate lên session
			session.setAttribute(Constant.SOFT_BY_END_DATE, softByEnddate);
			// set sortType lên session
			session.setAttribute(Constant.SORT_TYPE, sortType);
			// Di chuyển đến màn hình ADM002
			request.getRequestDispatcher(Constant.JSP_ADM002).forward(request, response);
			// xử lý ngoại lệ
		} catch (Exception e) {
			// Ghi log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển đến trang system Eror
			response.sendRedirect(request.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
					+ Constant.ER015);
		}
	}
}
