/**
 * 
 */
package manageuser.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.entities.UserInfo;
import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.utils.Common;
import manageuser.utils.Constant;
import manageuser.validates.ValidateUser;

/**
 * Controller xử lý cho MH ADM003_trường hợp editUser
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class EditUserInputController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Xử lý từ MH ADM005 sang ADM003
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Khởi tạo đối tượng userInfor
			UserInfo userInfor = new UserInfo();
			// Lấy về userId từ request
			int userId = Common.conVertStringToInt(req.getParameter(Constant.USER_ID), Constant.USER_ID_DEFAULT);
			// Khởi tạo đối tượng tblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
			// Kiểm tra userId đã tồn tại chưa
			if (userId > 0 && tblUserLogicImpl.checkExitUserId(userId)) {
				// set giá trị cho các hạng mục selectbox ở màn hình ADM003
				Common.setDataLogic(req);
				// gọi đến hàm getDefaultValue lấy về đối tượng userInfor trường hợp default
				userInfor = getDefaultValue(req, userId);
				// set userInfor lên request
				req.setAttribute(Constant.USER_INFOR, userInfor);
				// chuyển sang màn hình ADM003
				req.getRequestDispatcher(Constant.JSP_ADM003).forward(req, resp);
			} else {
				// chuyển sang màn hình Systerm Error lỗi ER013
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER013);
			}

		} catch (Exception e) {
			// Ghi log lại
			// chuyển sang màn hình Systerm Error lỗi ER015
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}

	/**
	 * Xử lý khi click button xác nhận trên MH ADM003
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Lấy ra session của Project
			HttpSession session = req.getSession();
			// Khởi tạo đối tượng userInfor
			UserInfo userInfor = new UserInfo();
			// Khởi tạo đối tượng tblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
			// Lấy userId từ request
			int userId = Integer.parseInt(req.getParameter(Constant.USER_ID));
			// Kiểm tra userId đã tồn tại chưa
			if (userId > 0 && tblUserLogicImpl.checkExitUserId(userId)) {

				userInfor = getDefaultValue(req, userId);
				// Khởi tạo đối tượng ValidateUser
				ValidateUser ValidateUser = new ValidateUser();
				// Kiểm tra các hạng mục nhập vào ở màn hình ADM003
				List<String> listErro = ValidateUser.validateUserInfor(userInfor);
				// nếu có lỗi
				if (listErro.size() > 0) {
					// set list lỗi lên request
					req.setAttribute(Constant.LIST_ERRO, listErro);
					// set UserInfor lên request
					req.setAttribute(Constant.USER_INFOR, userInfor);
					// set giá trị cho các hạng mục selectbox ở màn hình ADM003
					Common.setDataLogic(req);
					// di chuyển đến MH ADM003
					req.getRequestDispatcher(Constant.JSP_ADM003).forward(req, resp);
				} else {
					// set 1 biến check đã đi qua ADM003 trước đi tới ADM004 có giá trị = true lên
					// session
					session.setAttribute(Constant.CHECK, true);
					// tạo một khóa key
					String key = Common.getkey();
					// set userInfor lên session theo key, key này dùng để xử lý TH Back từ 2 tab
					// khác nhau
					session.setAttribute(key, userInfor);
					// Chuyển hướng sang controller AddUserConfirm
					resp.sendRedirect(
							req.getContextPath() + Constant.EDIT_USER_CONFIRM + "?" + Constant.KEY + "=" + key);
				}
			} else {
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER013);
			}
		} catch (Exception e) {
			// Ghi lại log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển hướng sang màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}

	private UserInfo getDefaultValue(HttpServletRequest req, int userId)
			throws ClassNotFoundException, SQLException, IOException {
		// Khởi tạo đối tượng userInfor
		UserInfo userInfor = new UserInfo();
		// Khởi tạo đối tượng tblUserLogicImpl
		TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
		// Lấy ra action type dùng để phân biệt trường hợp default từ MH ADM005
		// sang ADM003 hay từ ADM003 submit bị lỗi hay từ ADM004 back lại
		String type = req.getParameter(Constant.TYPE);
		// Khởi tạo giá trị StartDate và EndDate
		String startDate = Constant.EMPTY;
		String endDate = Constant.EMPTY;
		// Trường hợp action type là validate
		if (Constant.VALIDATE.equals(type)) {
			// Lấy thông tin từ các hạng mục người dùng nhập vào
			String loginName = req.getParameter(Constant.LOGIN_NAME);
			String fullName = req.getParameter(Constant.FULLNAME);
			String fullNameKana = req.getParameter(Constant.FULLNAME_KANA);
			String email = req.getParameter(Constant.EMAIL);
			String tel = req.getParameter(Constant.TEL);
			String pass = req.getParameter(Constant.PASS_WORD);
			String rePass = req.getParameter(Constant.REPASSWORD);
			String codeLevel = req.getParameter(Constant.CODELEVEL);
			int groupId = Integer.parseInt(req.getParameter(Constant.GROUPID));
			String total = req.getParameter(Constant.TOTAL);

			int birthYear = Integer.parseInt(req.getParameter(Constant.BIRTH_YEAR));
			int birthMonth = Integer.parseInt(req.getParameter(Constant.BIRTH_MONTH));
			int birthDay = Integer.parseInt(req.getParameter(Constant.BIRTH_DAY));
			String birthDate = Common.convertToString(birthYear, birthMonth, birthDay);

			int startYear = Integer.parseInt(req.getParameter(Constant.START_YEAR));
			int startMonth = Integer.parseInt(req.getParameter(Constant.START_MONTH));
			int startDay = Integer.parseInt(req.getParameter(Constant.START_DAY));
			startDate = Common.convertToString(startYear, startMonth, startDay);

			int endYear = Integer.parseInt(req.getParameter(Constant.END_YEAR));
			int endMonth = Integer.parseInt(req.getParameter(Constant.END_MONTH));
			int endDay = Integer.parseInt(req.getParameter(Constant.END_DAY));
			endDate = Common.convertToString(endYear, endMonth, endDay);
			// set các giá trị vào UserInfor
			userInfor.setUserId(userId);
			userInfor.setLoginName(loginName);
			userInfor.setFullName(fullName);
			userInfor.setFullNameKana(fullNameKana);
			userInfor.setEmail(email);
			userInfor.setTel(tel);
			userInfor.setPass(pass);
			userInfor.setRePass(rePass);
			userInfor.setCodeLevel(codeLevel);
			userInfor.setGroupId(groupId);
			userInfor.setTotal(total);
			userInfor.setBirthday(birthDate);
			userInfor.setStartDate(startDate);
			userInfor.setEndDate(endDate);
			// Trường hợp type là back
		} else if (Constant.BACK.equals(type)) {
			HttpSession session = req.getSession();
			// Lấy ra key từ URL
			String key = req.getParameter(Constant.KEY);
			// Lấy ra userInfor từ session theo key
			userInfor = (UserInfo) session.getAttribute(key);
		} else {

			userInfor = tblUserLogicImpl.getUserInforById(userId);
			String birthDay = Common.changeToDay(userInfor.getBirthday());
			// Nếu không có trình độ tiếng Nhật
			if (userInfor.getNameLevel() == null) {
				// Lấy ra ngày tháng năm hiện tại
				int yearNow = Common.getYearNow();
				int monthNow = Common.getMonthNow();
				int dayNow = Common.getDayNow();
				startDate = Common.convertToString(yearNow, monthNow, dayNow);
				endDate = Common.convertToString(yearNow + 1, monthNow, dayNow);
			} else {
				// Nếu có trình độ tiếng Nhật
				startDate = Common.changeToDay(userInfor.getStartDate());
				endDate = Common.changeToDay(userInfor.getEndDate());
			}
			// set lại các giá trị cho userInfor
			userInfor.setUserId(userId);
			userInfor.setBirthday(birthDay);
			userInfor.setStartDate(startDate);
			userInfor.setEndDate(endDate);
		}
		return userInfor;
	}
}
