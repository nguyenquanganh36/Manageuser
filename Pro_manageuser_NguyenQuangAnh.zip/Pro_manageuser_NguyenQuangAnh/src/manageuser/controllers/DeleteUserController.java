/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.utils.Constant;

/**
 * Controller xử lý xoá user
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class DeleteUserController extends HttpServlet {

	/**
	 * Biến tự khởi tạo serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Xử lý khi thực hiện click button Xoá
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
//			Lấy userId từ request
			int userId = Integer.parseInt(req.getParameter(Constant.USER_ID));
//			Khởi tạo đối tượng tblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
//			Khởi tạo message chứa câu thông báo lỗi
			String message = tblUserLogicImpl.getMessageRuleUserId(userId);
//			nếu có lỗi
			if (!Constant.EMPTY.equals(message)) {
//				chuyển sang controller systerm error
				resp.sendRedirect(
						req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + message);
			} else {
//				Thực hiện xoá user
				tblUserLogicImpl.deleteUserInfor(userId);
//				Nếu quá trình xóa không xảy ra lỗi thì trả về màn hình xóa thành công
				resp.sendRedirect(req.getContextPath() + Constant.SUCCESS_URL + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.MSG003);
			}
		} catch (Exception e) {
//			Ghi log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
//			SendRedirect đến controller systerm error với mã lỗi ER015
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}
}
