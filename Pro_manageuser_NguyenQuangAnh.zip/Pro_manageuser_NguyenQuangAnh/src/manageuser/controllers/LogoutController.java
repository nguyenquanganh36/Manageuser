/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.utils.Constant;

/**
 * Controller xử lý việc logout
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class LogoutController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Xử lý logout
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// lấy về session hiện tại
			HttpSession session = req.getSession();
			// xoá session
			session.invalidate();
			// chuyển tiếp về trang jsp ADM001
			req.getRequestDispatcher(Constant.JSP_ADM001).forward(req, resp);
		} catch (Exception e) {
			// Ghi lại log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển hướng sang màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}
}
