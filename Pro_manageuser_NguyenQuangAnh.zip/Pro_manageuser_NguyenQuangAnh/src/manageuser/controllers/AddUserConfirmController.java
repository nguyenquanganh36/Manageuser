/**
 * 
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import manageuser.entities.UserInfo;
import manageuser.logics.MstGroupLogic;
import manageuser.logics.MstJapanLogic;
import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.MstGroupLogicImpl;
import manageuser.logics.impl.MstJapanLogicImpl;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.utils.Constant;

/**
 * Controller xử lý cho màn hình ADM004_trường hợp addUser
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class AddUserConfirmController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * xử lý từ màn hình ADM003 sang ADM004
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Lấy session hiện tại
			HttpSession session = req.getSession();
			// Lấy biến check đã chạy qua màn hình ADM003 chưa từ session
			boolean check = (boolean) session.getAttribute(Constant.CHECK);
			if (check) {
				// Lấy key từ url
				String key = req.getParameter(Constant.KEY);
				// Lấy userInfor từ session theo key
				UserInfo userInfor = (UserInfo) session.getAttribute(key);
				// Khởi tạo đối tượng MstGroupLogicImpl
				MstGroupLogic mstGroupLogicImpl = new MstGroupLogicImpl();
				// Khởi tạo đối tượng MstJapanLogicImpl
				MstJapanLogic mstJapanLogicImpl = new MstJapanLogicImpl();
				// Lấy tên groupName theo groupID truyền vào
				String groupName = mstGroupLogicImpl.getMstGroupById(userInfor.getGroupId()).getGroupName();
				// Lấy tên nameLevel theo codeLevel truyền vào
				String nameLevel = mstJapanLogicImpl.getNameLevelByCodeLevel(userInfor.getCodeLevel());
				// set groupName cho userInfor
				userInfor.setGroupName(groupName);
				// set nameLevel cho userInfor
				userInfor.setNameLevel(nameLevel);
				// xoá biến check chạy qua màn hình ADM003
				session.removeAttribute(Constant.CHECK);
				// Set userInfor lên req để truyền sang jsp
				req.setAttribute(Constant.USER_INFOR, userInfor);
				// Set key lên req
				req.setAttribute(Constant.KEY, key);
				// Di chuyển đến màn hình ADM004
				req.getRequestDispatcher(Constant.JSP_ADM004).forward(req, resp);
			} else {
				// Ghi log
				System.out.println();
				// Chuyển hướng ra màn hình lỗi
				// Start fix bug ID 12 – AnhNQ 2019/12/25
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER015);
				// End fix bug ID 12 – AnhNQ 2019/12/25
			}
		} catch (Exception e) {
			// Ghi log lại
			System.out.println("AddUserConfirmController : doGet" + e.getMessage());
			// Chuyển hướng ra màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}

	}

	/**
	 * Xử lý khi submit màn hình ADM004
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Lấy session hiện tại
			HttpSession session = req.getSession();
			// Lấy về giá trị key
			String key = req.getParameter(Constant.KEY);
			// Lấy userInfor từ session theo key truyền vào
			UserInfo userInfor = (UserInfo) session.getAttribute(key);
			// xoá key
			session.removeAttribute(key);
			// Khởi tạo đối tượng tblUserLogic
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
			// Kiểm tra tồn tại loginName
			boolean checkExistLoginName = tblUserLogicImpl.checkExistLoginName(userInfor.getLoginName());
			// Kiểm tra tồn tại email
			boolean checkExistEmail = tblUserLogicImpl.checkExistEmail(userInfor.getEmail(), userInfor.getUserId());
			// Nếu loginName và email chưa tồn tại trong DB
			if (!checkExistLoginName && !checkExistEmail) {
				// Thực hiện thêm mới userInfor
				tblUserLogicImpl.createUser(userInfor);
				// Nếu thêm mới thành công thì hiển thị MH ADM006 với thông báo đăng kí user
				// thành công
				resp.sendRedirect(req.getContextPath() + Constant.SUCCESS_URL + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.MSG001);
			} else {
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER015);
			}
		} catch (Exception e) {
			// Ghi lại log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển hướng sang màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}

	}
}
