/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.utils.Constant;
import manageuser.validates.LoginValidate;

/**
 * Controller xử lý cho màn hình Login ADM001
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class LoginController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher(Constant.JSP_ADM001).forward(request, response);
	}

	/**
	 * Xử lý khi click button đăng nhập ở MH ADM001
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
//		Lấy tên đăng nhập trên form
			String loginName = request.getParameter(Constant.LOGIN_NAME);
//		Lấy mật khẩu trên form	
			String password = request.getParameter(Constant.PASSWORD);
//			Khởi tạo đối tượng LoginValidate
			LoginValidate loginValidate = new LoginValidate();
//			Khởi tạo 1 listErr lỗi với giá trị bằng giá trị trả về của phương thức kiểm tra đăng nhập
			ArrayList<String> listError = loginValidate.loginValidate(loginName, password);
// 			Nếu không có lỗi
			if (listError.isEmpty()) {
//				Khởi tạo session
				HttpSession session = request.getSession();
				// Set loginName lên session
				session.setAttribute(Constant.LOGIN_NAME, loginName);
				// Chuyển đến trang ADM002
				response.sendRedirect(request.getContextPath() + Constant.LISTUSER_URL + "?" + Constant.TYPE + "="
						+ Constant.DEFAULT);
			} else {
				// Set danh sách lỗi lên request để hiển thị lỗi
				request.setAttribute(Constant.LIST_ERROR, listError);
//				Set loginName lên request
				request.setAttribute(Constant.LOGIN_NAME, loginName);
				// Chuyển hướng sang màn hình Login
				request.getRequestDispatcher(Constant.JSP_ADM001).forward(request, response);
			}

		} catch (Exception e) {
			// log lại lỗi
			System.out.println("LoginControllers : doPost " + e.getMessage());
			// chuyển tiếp đến màn hình System_Error
			request.getRequestDispatcher(Constant.JSP_SYSTEM_ERRPOR).forward(request, response);
		}
	}
}
