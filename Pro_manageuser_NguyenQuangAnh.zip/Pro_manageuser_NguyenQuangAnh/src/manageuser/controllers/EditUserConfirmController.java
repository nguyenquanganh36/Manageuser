/**
 * 
 */
package manageuser.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.entities.UserInfo;
import manageuser.logics.MstGroupLogic;
import manageuser.logics.MstJapanLogic;
import manageuser.logics.TblDetailUserJapanLogic;
import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.MstGroupLogicImpl;
import manageuser.logics.impl.MstJapanLogicImpl;
import manageuser.logics.impl.TblDetailUserJapanLogicImpl;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.utils.Constant;

/**
 * Controller xử lý cho MH ADM004_trường hợp editUser
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class EditUserConfirmController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Chuyển từ màn hình ADM003 sang ADM004 cho chức năng Edit
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Lấy về session hiện tại
			HttpSession session = req.getSession();
			// Lấy biến check đã chạy qua ADM003 trước khi đến ADM004 chưa từ session
			boolean check = (boolean) session.getAttribute(Constant.CHECK);
			if (check) {
				// Lấy key từ url
				String key = req.getParameter(Constant.KEY);
				// Lấy userInfor từ session theo key
				UserInfo userInfor = (UserInfo) session.getAttribute(key);
				// Khởi tạo đối tượng MstGroupLogicImpl
				MstGroupLogic mstGroupLogicImpl = new MstGroupLogicImpl();
				// Khởi tạo đối tượng MstJapanLogicImpl
				MstJapanLogic mstJapanLogicImpl = new MstJapanLogicImpl();
				// Lấy tên groupName theo groupID truyền vào
				String groupName = mstGroupLogicImpl.getMstGroupById(userInfor.getGroupId()).getGroupName();
				// Lấy tên nameLevel theo codeLevel truyền vào
				String nameLevel = mstJapanLogicImpl.getNameLevelByCodeLevel(userInfor.getCodeLevel());
				// set groupName cho userInfor
				userInfor.setGroupName(groupName);
				// set nameLevel cho userInfor
				userInfor.setNameLevel(nameLevel);
				session.removeAttribute(Constant.CHECK);
				// Set thông tin lên để truyền sang jsp
				req.setAttribute(Constant.USER_INFOR, userInfor);
				req.setAttribute(Constant.KEY, key);
				// di chuyển đến màn hình ADM004
				req.getRequestDispatcher(Constant.JSP_ADM004).forward(req, resp);
			} else {
				// Ghi log
				System.out.println();
				// Chuyển hướng ra màn hình lỗi
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER015);
			}

		} catch (Exception e) {
			// Ghi log lại
			System.out.println("AddUserConfirmController : doGet" + e.getMessage());
			// Chuyển hướng ra màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}

	/**
	 * Thực hiện khi click button OK submit form trên MH ADM004 cho chức năng Edit
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
//			lấy về session hiện tại
			HttpSession session = req.getSession();
//			Khởi tạo đối tượng TblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
//			Khởi tạo đối tượng TblDetailUserJapanLogicImpl
			TblDetailUserJapanLogic tblDetailUserJapanLogicImpl = new TblDetailUserJapanLogicImpl();
//			Lấy ra key
			String key = req.getParameter(Constant.KEY);
//			Lấy ra userInfor từ session theo key
			UserInfo userInfor = (UserInfo) session.getAttribute(key);
//			Xóa key 
			session.removeAttribute(key);
//			Kiểm tra tồn tại userId
//			Tạo 1 biến checkExitUserId
			boolean checkExitUserId = tblUserLogicImpl.checkExitUserId(userInfor.getUserId());
//			Nếu tồn tại userId
			if (checkExitUserId) {
//				Kiểm tra tồn tại email
//				Tạo một biến checkExitEmail
				boolean checkExitEmail = tblUserLogicImpl.checkExistEmail(userInfor.getEmail(), userInfor.getUserId());
				if (!checkExitEmail) {
//					Kiểm tra tồn tại trình độ tiếng Nhật trong Database theo userId truyền vào
					boolean check = tblDetailUserJapanLogicImpl.checkExitDetailUserJapan(userInfor.getUserId());
					tblUserLogicImpl.editUser(userInfor, check);
					resp.sendRedirect(req.getContextPath() + Constant.SUCCESS_URL + "?" + Constant.TYPE_MESSAGE + "="
							+ Constant.MSG002);
				}
			} else {
				resp.sendRedirect(req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "="
						+ Constant.ER013);
			}
		} catch (Exception e) {
			// Ghi log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}

	}
}
