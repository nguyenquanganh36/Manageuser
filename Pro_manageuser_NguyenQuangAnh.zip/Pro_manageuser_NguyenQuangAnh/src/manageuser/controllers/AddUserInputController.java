/**
 * copy right luvina
 */
package manageuser.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.entities.UserInfo;
import manageuser.utils.Common;
import manageuser.utils.Constant;
import manageuser.validates.ValidateUser;

/**
 * Controller xử lý cho màn hình ADM003_trường hợp addUser
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class AddUserInputController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * Xử lý di chuyển từ Mh ADM002 sang ADM003
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Khởi tạo đối tượng userInfor
			UserInfo userInfor = new UserInfo();
			// set giá trị cho các hạng mục selectbox ở màn hình ADM003
			Common.setDataLogic(req);
			// Lấy về đối tượng UserInfor
			userInfor = getDefaultValue(req);
			// set UserInfor lên request
			req.setAttribute(Constant.USER_INFOR, userInfor);
			// Chuyển đến màn hình ADM003
			req.getRequestDispatcher(Constant.JSP_ADM003).forward(req, resp);

		} catch (Exception e) {
			// Ghi log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển đến trang system Eror
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}

	/**
	 * Xử lý button xác nhận bên ADM003 check validate
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// Lấy ra session của Project
			HttpSession session = req.getSession();
			// Khởi tạo đối tượng userInfor
			UserInfo userInfor = new UserInfo();
//			gọi đến hàm getDefaultValue lấy về đối tượng userInfor trường hợp validate
			userInfor = getDefaultValue(req);
//			Khởi tạo đối tượng ValidateUser
			ValidateUser validateUser = new ValidateUser();
			// thực hiện validate thông tin user
			List<String> listErro = validateUser.validateUserInfor(userInfor);
			// nếu có lỗi
			if (listErro.size() > 0) {
				// set list lỗi lên request
				req.setAttribute(Constant.LIST_ERRO, listErro);
				// set userInfor lên request
				req.setAttribute(Constant.USER_INFOR, userInfor);
				// set giá trị cho các hạng mục selectbox ở màn hình ADM003
				Common.setDataLogic(req);
				// Di chuyển đến màn hình ADM003
				req.getRequestDispatcher(Constant.JSP_ADM003).forward(req, resp);
			} else {
				// set 1 biến check có giá trị băng true lên session
				session.setAttribute(Constant.CHECK, true);
				// tạo một khóa key
				String key = Common.getkey();
				// set userInfor leen session theo key
				session.setAttribute(key, userInfor);
				// Chuyển hướng sang controller AddUserConfirm
				resp.sendRedirect(req.getContextPath() + Constant.ADD_USER_CONFIRM + "?" + Constant.KEY + "=" + key);
			}
		} catch (Exception e) {
			// Ghi lại log
			System.out.println("Class: " + this.getClass().getName() + ", Method: "
					+ e.getStackTrace()[0].getMethodName() + ", Error: " + e.getMessage());
			// Chuyển hướng sang màn hình lỗi
			resp.sendRedirect(
					req.getContextPath() + Constant.SYSTEM_ERRORS + "?" + Constant.TYPE_MESSAGE + "=" + Constant.ER015);
		}
	}

	/**
	 * Hàm lấy về đối tượng userInfor cho 3 trường hợp:1. Từ ADM002 sang ADM003, 2.
	 * Từ ADM003 submit nhưng bị lỗi, 3. Từ ADM004 quay về ADM003
	 * 
	 * @param req đối tượng HttpServletRequest
	 * @return đối tượng userInfor
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private UserInfo getDefaultValue(HttpServletRequest req) throws ClassNotFoundException, SQLException {
		// Khởi tạo đối tượng userInfor
		UserInfo userInfor = new UserInfo();
		// Lấy ra action type từ request
		String type = req.getParameter(Constant.TYPE);
		// Trường hợp DEFAULT khởi tạo các thuộc tính default của UserInfor
		String loginName = Constant.EMPTY;
		String fullName = Constant.EMPTY;
		String fullNameKana = Constant.EMPTY;
		String email = Constant.EMPTY;
		String tel = Constant.EMPTY;
		String pass = Constant.EMPTY;
		String rePass = Constant.EMPTY;
		String codeLevel = Constant.EMPTY;
		int groupId = Constant.GROUP_ID_DEFAULT;
		String total = Constant.EMPTY;
		int yearNow = Common.getYearNow();
		int monthNow = Common.getMonthNow();
		int dayNow = Common.getDayNow();
		String birthDate = Common.convertToString(yearNow, monthNow, dayNow);
		String startDate = Common.convertToString(yearNow, monthNow, dayNow);
		String endDate = Common.convertToString(yearNow + 1, monthNow, dayNow);
		// Trường hợp action type là validate
		if (Constant.VALIDATE.equals(type)) {
			// Lấy thông tin từ form set cho các thuộc tính của userInfor
			loginName = req.getParameter(Constant.LOGIN_NAME);
			fullName = req.getParameter(Constant.FULLNAME);
			fullNameKana = req.getParameter(Constant.FULLNAME_KANA);
			email = req.getParameter(Constant.EMAIL);
			tel = req.getParameter(Constant.TEL);
			pass = req.getParameter(Constant.PASS_WORD);
			rePass = req.getParameter(Constant.REPASSWORD);
			codeLevel = req.getParameter(Constant.CODELEVEL);
			groupId = Integer.parseInt(req.getParameter(Constant.GROUPID));
			total = req.getParameter(Constant.TOTAL);

			int birthYear = Integer.parseInt(req.getParameter(Constant.BIRTH_YEAR));
			int birthMonth = Integer.parseInt(req.getParameter(Constant.BIRTH_MONTH));
			int birthDay = Integer.parseInt(req.getParameter(Constant.BIRTH_DAY));
			birthDate = Common.convertToString(birthYear, birthMonth, birthDay);

			int startYear = Integer.parseInt(req.getParameter(Constant.START_YEAR));
			int startMonth = Integer.parseInt(req.getParameter(Constant.START_MONTH));
			int startDay = Integer.parseInt(req.getParameter(Constant.START_DAY));
			startDate = Common.convertToString(startYear, startMonth, startDay);

			int endYear = Integer.parseInt(req.getParameter(Constant.END_YEAR));
			int endMonth = Integer.parseInt(req.getParameter(Constant.END_MONTH));
			int endDay = Integer.parseInt(req.getParameter(Constant.END_DAY));
			endDate = Common.convertToString(endYear, endMonth, endDay);

		}
		// Trường hợp action type là back
		if (Constant.BACK.equals(type)) {
//			Lấy về session hiện tại
			HttpSession session = req.getSession();
			// lấy ra key từ URL
			String key = req.getParameter(Constant.KEY);
			// Lấy ra userInfor từ session theo key vừa lấy được
			userInfor = (UserInfo) session.getAttribute(key);
		} else {
			// set các giá trị của thuộc tính vào UserInfor
			userInfor.setLoginName(loginName);
			userInfor.setFullName(fullName);
			userInfor.setFullNameKana(fullNameKana);
			userInfor.setEmail(email);
			userInfor.setTel(tel);
			userInfor.setPass(pass);
			userInfor.setRePass(rePass);
			userInfor.setCodeLevel(codeLevel);
			userInfor.setGroupId(groupId);
			userInfor.setTotal(total);
			userInfor.setBirthday(birthDate);
			userInfor.setStartDate(startDate);
			userInfor.setEndDate(endDate);
		}
// Trả về đối tượng userInfor
		return userInfor;
	}

}
