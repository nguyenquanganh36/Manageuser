/**
 * copy right luvina
 */
package manageuser.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import manageuser.dao.TblUserDao;
import manageuser.dao.impl.TblUserDaoImpl;
import manageuser.entities.MstGroupBean;
import manageuser.entities.MstJapanBean;
import manageuser.entities.TblUserBean;
import manageuser.logics.MstGroupLogic;
import manageuser.logics.MstJapanLogic;
import manageuser.logics.impl.MstGroupLogicImpl;
import manageuser.logics.impl.MstJapanLogicImpl;
import manageuser.properties.LimitProperties;

/**
 * Class chứa các phương thức dùng chung của Project
 * 
 * @author LA-PM
 *
 */
public class Common {
	/**
	 * Hàm mã hoá password nhập vào
	 * 
	 * @param password
	 * @param salt
	 * @return password đã được mã hoá
	 * @throws NoSuchAlgorithmException
	 */
	public static String encryptSHA1(String password, String salt) throws NoSuchAlgorithmException {
		StringBuffer str = new StringBuffer();
		try {
			String input = salt + password;
			MessageDigest md = MessageDigest.getInstance("SHA-1");
			byte[] messageDigest = md.digest(input.getBytes());
			// hashedText = new String(messageDigest);
			for (int i = 0; i < messageDigest.length; i++) {
				str.append(Integer.toString((messageDigest[i] & 0xff) + 0x100, 16).substring(1));
			}
		} catch (NoSuchAlgorithmException e) {
			System.out.println("Common encryptSHA1" + e.getMessage());
			throw e;

		}
		return str.toString();
	}

	/**
	 * Hàm so sánh 2 chuỗi String với nhau
	 * 
	 * @param str1
	 * @param str2
	 * @return true nếu giống nhau, false nếu khác nhau
	 */
	public static boolean compareString(String str1, String str2) {
		boolean check = false;
		if (str1.equals(str2)) {
			check = true;
		}
		return check;
	}

	/**
	 * Hàm kiểm tra login
	 * 
	 * @param session
	 * @return trạng thái login
	 */
	public static boolean checkLogin(HttpSession session) throws SQLException, ClassNotFoundException{
		boolean check = false;
		try {
			// Khởi tạo giá trị cho biến check
			String loginName = (String) session.getAttribute(Constant.LOGIN_NAME);
			// Kiểm tra người dùng đã đăng nhập và có phải là admin hay không
			if (loginName != null) {
				TblUserDao TblUserDaoImpl = new TblUserDaoImpl();
				TblUserBean user = TblUserDaoImpl.getUserByLoginName(loginName);
				if (user != null) {
					check = true;
				}
			}
		} catch (SQLException | ClassNotFoundException e) {
			throw e;
		}

		return check;

	}

	/**
	 * Hàm thay thế chuỗi nhập để tránh lỗi SQLEjection
	 * 
	 * @param text đoạn chuỗi cần thay thế
	 * @return đoạn chuỗi được thay thế
	 */
	public static String replaceWildCard(String text) {
		text = text.replace("%", "\\%");
		text = text.replace("_", "\\_");
		return text;
	}

	/**
	 * Lấy vị trí data cần lấy
	 * 
	 * @param currentPage Trang hiện tại
	 * @param limit       số lượng cần hiển thị trên 1 trang
	 * @return
	 */
	public static int getOffset(int currentPage, int limit) {
		int tamp = 0;
		if (currentPage > 0) {
			tamp = limit * (currentPage - 1);
		}
		return tamp;
	}

	/**
	 * Lấy số lượng hiển thị bản ghi trên 1 trang
	 *
	 * @return limit số lượng recorscần lấy
	 */
	public static int getLimit() {
		int limit = Integer.parseInt(LimitProperties.getValueByKey("LIMIT"));
		return limit;
	}

	/**
	 * Lấy số lượng trang trên nhóm paging
	 * 
	 * @return limitpage số lượng trang trên paging
	 */
	public static int getLimitPage() {
		int limitpage = Integer.parseInt(LimitProperties.getValueByKey("LIMITPAGE"));
		return limitpage;
	}

	/**
	 * Hàm tính tổng số trang
	 * 
	 * @param totalUser
	 * @param limit
	 * @return totalPage tổng số trang
	 */
	public static int getTotalPage(int totalUser, int limit) {
		int totalPage = (int) Math.ceil(totalUser * 1.0 / limit);
		return totalPage;
	}

	/**
	 * Hàm lấy ra nhóm page để hiển thị lên paging
	 * 
	 * @param currentPage
	 * @param limitPage
	 * @return
	 */
	public static int getCurrentGroup(int currentPage, int limitPage) {
		int currentGroup = (int) Math.ceil(currentPage * 1.0 / limitPage);
		return currentGroup;
	}

	/**
	 * Hàm lấy về trang nhỏ nhất trong currentGroup
	 * 
	 * @param currentGroup
	 * @param limitPage
	 * @return minCurrentGroup trang nhỏ nhất trong currentGroup
	 */
	public static int getMinCurrentGroup(int currentGroup, int limitPage) {
		int minCurrentGroup = (currentGroup - 1) * limitPage + 1;
		return minCurrentGroup;
	}

	/**
	 * Hàm lấy về trang lớn nhất trong currentGroup
	 * 
	 * @param currentGroup
	 * @param limitPage
	 * @return maxCurrentGroup trang lớn nhất trong currentGroup
	 */
	public static int getMaxCurrentGroup(int currentGroup, int limitPage) {
		int maxCurrentGroup = currentGroup * limitPage;
		return maxCurrentGroup;
	}

	/**
	 * Hàm lấy list các page hiện tại trong trang hiện tại
	 * 
	 * @param totalPage
	 * @param limit
	 * @param currentPage
	 * @return listPaging Danh sách các trang cần hiển thị ở chuỗi paging theo trang
	 *         hiện tại
	 */
	public static List<Integer> getListPaging(int totalPage, int currentPage) {
		List<Integer> listPaging = new ArrayList<Integer>();
		int limitPage = Integer.parseInt(LimitProperties.getValueByKey("LIMITPAGE"));
		int currentGroup = Common.getCurrentGroup(currentPage, limitPage);
		int minCurrentGroup = getMinCurrentGroup(currentGroup, limitPage);
		int maxCurrentGroup = getMaxCurrentGroup(currentGroup, limitPage);
		if (maxCurrentGroup > totalPage) {
			maxCurrentGroup = totalPage;
		}
		if (minCurrentGroup != maxCurrentGroup || (minCurrentGroup != 1 && minCurrentGroup == maxCurrentGroup)) {
			for (int i = minCurrentGroup; i <= maxCurrentGroup; i++) {
				listPaging.add(i);
			}
		}
		return listPaging;
	}

	public static int checkCurrentPage(int totalPage, int currentPage) {
		if (currentPage > totalPage) {
			currentPage = totalPage;
		}
		// phần này chuyển sang hàm convertStringToInt
		if (currentPage <= 0) {
			currentPage = 1;
		}
		return currentPage;
	}

	/**
	 * Hàm parseInt tu String sang Int, nếu không parseInt được thì chuyển về các
	 * giá trị mặc định
	 * 
	 * @param value        giá trị truyền vào
	 * @param valueDefault giá trị mặc định
	 * @return giá trị sau khi parse
	 */
	public static int conVertStringToInt(String value, int valueDefault) {
//		Khai báo biến ketQua kiểu int có giá trị bằng giá trị mặc định
		int ketQua = valueDefault;
		try {
//			Kiểm tra giá trị value truyền vào 
			if (!value.isEmpty()) {
				// Nếu value khác rỗng thì parse giá trị truyền vào sang số nguyên
				ketQua = Integer.parseInt(value);
			}
		} catch (NumberFormatException e) {
			// Gán ketQua về giá trị mặc định
			ketQua = valueDefault;
		}
//		Trả về kết quả
		return ketQua;
	}

	/**
	 * Hàm check tồn tại column trong mảng danh sách các column cần orderby
	 * 
	 * @param arrList arrList mảng danh sách các column
	 * @param str     column cần check
	 * @return true nếu tồn tại trong list, false nếu không tồn tại
	 */
	public static boolean checkExitColumn(List<String> arrList, String str) {
		// Khai báo và khởi tạo biến check kiểu boolean có giá trị = false
		boolean check = false;
		// Kiểm tra sự tồn tại của str trong arrList
		if (arrList.contains(str)) {
			// Nếu str có tồn tại trong arrList, gán biến check = true
			check = true;
		}
		// Trả về check
		return check;
	}

	/**
	 * Hàm lấy ra danh sách các năm
	 * 
	 * @param fromYear
	 * @param toYear
	 * @return listYear: 1 list các năm
	 */
	public static List<Integer> getListYear(int fromYear, int toYear) {
		List<Integer> listYear = new ArrayList<>();
		for (int i = fromYear; i <= toYear; i++) {
			listYear.add(i);
		}
		return listYear;
	}

	/**
	 * Hàm lấy ra danh sách các tháng
	 * 
	 * @return listMonth 1 list các tháng từ 1 đến 12
	 */
	public static List<Integer> getListMonth() {
		List<Integer> listMonth = new ArrayList<>();
		for (int i = 1; i <= 12; i++) {
			listMonth.add(i);
		}
		return listMonth;
	}

	/**
	 * Hàm lấy danh sách các ngày
	 * 
	 * @return listDay 1 list các ngày từ 1 đến 31
	 */
	public static List<Integer> getListDay() {
		List<Integer> listDay = new ArrayList<>();
		for (int i = 1; i <= 31; i++) {
			listDay.add(i);
		}
		return listDay;
	}

	/**
	 * Hàm lấy ra năm hiện tại
	 * 
	 * @return yearNow: năm hiện tại
	 */
	public static int getYearNow() {
		Calendar calendar = Calendar.getInstance();
		int yearNow = calendar.get(Calendar.YEAR);
		return yearNow;
	}

	/**
	 * Hàm lấy ra tháng hiện tại
	 * 
	 * @return monthNow: tháng hiện tại
	 */
	public static int getMonthNow() {
		int monthNow = Calendar.getInstance().get(Calendar.MONTH) + 1;
		return monthNow;
	}

	/**
	 * Hàm lấy ra ngày hiện tại
	 * 
	 * @return dayNow: ngày hiện tại
	 */
	public static int getDayNow() {
		int dayNow = Calendar.getInstance().get(Calendar.DATE);
		return dayNow;
	}

	/**
	 * Chuyển ngày tháng năm thành chuỗi string
	 * 
	 * @param year  năm
	 * @param month tháng
	 * @param day   ngày
	 * @return 1 chuỗi string năm/tháng/ngày
	 */
	public static String convertToString(int year, int month, int day) {
		StringBuilder date = new StringBuilder();
		date.append(year).append("/");
		date.append(month).append("/");
		date.append(day);
		return date.toString();
	}

	/**
	 * Chuyển chuỗi thành 1 mảng chứa 3 giá trị năm, tháng, ngày
	 * 
	 * @param date: chuỗi năm tháng ngày
	 * @return mảng chứa giá trị năm tháng ngày
	 */
	public static int[] toArrayInteger(String date) {
		String[] dateSpilit = date.split("/");
		int[] arrDate = new int[3];
		for (int i = 0; i < arrDate.length; i++) {
			arrDate[i] = Integer.parseInt(dateSpilit[i]);
		}
		return arrDate;
	}

	/**
	 * Chuyển dạng YYYY/MM/DD thành YYYY-MM-DD
	 * 
	 * @param date
	 * @return chuỗi ngày tháng năm đã được chuyển
	 */
	public static String changeToDateType(String date) {
		date = date.replace("/", "-");
		return date;
	}

	/**
	 * Chuyển dạng YYYY-MM-DD thành YYYY/MM/DD
	 * 
	 * @param date
	 * @return chuỗi ngày tháng năm đã được chuyển
	 */
	public static String changeToDay(String date) {
		date = date.replace("-", "/");
		return date;
	}

	/**
	 * Hàm check không nhập
	 * 
	 * @param text
	 * @return true nếu không nhập, false nếu có nhập
	 */
	public static boolean checkEmpty(String text) {
		if ("".equals(text)) {
			return true;
		}
		return false;
	}

	/**
	 * Hàm lấy ra 1 key
	 * 
	 * @return
	 */
	public static String getkey() {
		return System.currentTimeMillis() + "";
	}

	/**
	 * Ham check format LoginName
	 * 
	 * @param text : chuỗi cần check
	 * @return true nếu LoginName đúng format, false nếu sai format
	 */
	public static boolean checkFormatLoginName(String text) {
		String loginNameFormat = "^[a-zA-Z][a-zA-Z_0-9]+";
		return text.matches(loginNameFormat);
	}

	/**
	 * Hàm check format Email
	 * 
	 * @param text : chuỗi cần check
	 * @return true nếu Email đúng format, false nếu sai format
	 */
	public static boolean checkFormatEmail(String text) {
		String emailFormat = "[a-zA-Z_0-9]+@[a-zA-Z]+\\.{1}[a-zA-Z]+$";
		return text.matches(emailFormat);
	}

	/**
	 * Hàm check format Tel
	 * 
	 * @param text : chuỗi cần check
	 * @return true nếu Tel đúng format, false nếu sai format
	 */
	public static boolean checkFormatTel(String text) {
		String telFormat = "[0-9]{1,4}-[0-9]{1,4}-[0-9]{1,4}";
		return text.matches(telFormat);
	}

	/**
	 * Hàm check format Total
	 * 
	 * @param text : chuỗi cần check
	 * @return true nếu Total đúng format, false nếu sai format
	 */
	public static boolean checkFormatTotal(String text) {
		String totalFormat = "[0-9]+";
		return text.matches(totalFormat);
	}

	/**
	 * Hàm check format fullNameKana
	 * 
	 * @param text : chuỗi cần check
	 * @return true nếu fullNameKana đúng format, false nếu sai format
	 */
	public static boolean checkKana(String text) {
		String fullNamekanaFormat = "[\\u30A0-\\u30FF\\uFF65-\\uFF9F　]*";
		return text.matches(fullNamekanaFormat);
	}

	/**
	 * Hàm check kí tự một byte
	 * 
	 * @param text : chuỗi cần check
	 * @return true nếu chuỗi chỉ gồm các kí tự một byte, false nếu chuỗi chứa cả
	 *         các kí tự không phải một byte
	 * @throws UnsupportedEncodingException
	 */
	public static boolean checkCharacterOneByte(String text) throws UnsupportedEncodingException {
		boolean check = false;
		try {
			int lengthText = text.length();
			int lengthByte = text.getBytes("UTF-8").length;
			if (lengthText == lengthByte) {
				check = true;
			}
		} catch (UnsupportedEncodingException e) {
			// ghi log
			throw e;
		}
		return check;

	}

	/**
	 * Hàm check xem chuỗi nhập vào có quá số lượng kí tự cho phép không
	 * 
	 * @param text      : chuỗi cần check
	 * @param maxLength : số kí tự tối đa
	 * @return true nếu chuỗi nhập vào vượt quá số kí tự cho phép, false nếu chuỗi
	 *         nhập vào không vượt quá số kí tự cho phép
	 */
	public static boolean checkMaxLength(String text, int maxLength) {
		if (text.length() > maxLength) {
			return true;
		}
		return false;
	}

	/**
	 * Hàm check độ dài của chuỗi nhập vào trong khoảng min đến max kí tự
	 * 
	 * @param text      : chuỗi cần check
	 * @param minLength : độ dài tối thiểu
	 * @param maxLength : độ dài tối đa
	 * @return true nếu độ dài của chuỗi nằm ngoài khoảng, false nếu nằm trong
	 *         khoảng
	 */
	public static boolean checkLength(String text, int minLength, int maxLength) {
		if (text.length() < minLength || text.length() > maxLength) {
			return true;
		}
		return false;
	}

	/**
	 * Hàm check không chọn selectbox
	 * 
	 * @param value : giá trị đang chọn
	 * @return true nếu chưa chọn, false nếu đã chọn
	 */
	public static boolean checkNoSelectSelectbox(int value) {
		if (value == 0) {
			return true;
		}
		return false;
	}

	/**
	 * Hàm check ngày tháng năm có hợp lệ hay không
	 * 
	 * @param Date
	 * @return true nếu hợp lệ, false nếu không hợp lệ
	 */
	public static boolean checkDate(String Date) {
		boolean check = false;
		int[] arrDate = toArrayInteger(Date);
		int year = arrDate[0];
		int month = arrDate[1];
		int day = arrDate[2];
		// neu la cac thang 4,6,9,11
		if (month == 4 || month == 6 || month == 9 || month == 11) {
			// neu ngay <=30
			if (day <= 30) {
				// gan check = true
				check = true;
			}
		} else if (month == 2) {
			// neu la nam nhuan
			if (year % 4 == 0) {
				// nau ngay <= 29
				if (day <= 29) {
					// gan check = true
					check = true;
				}
			} else {
				if (day <= 28) {
					// gan check = true
					check = true;
				}
			}
		} else {
			// neu la cac thang con lai ma co ngay <=31
			if (day <= 31) {
				// gan check = true
				check = true;
			}
		}
		return check;
	}

	/**
	 * Hàm kiểm tra xem endDate có hợp lệ hay không( endDate có > startDate hay
	 * không)
	 * 
	 * @param endDate
	 * @param startDate
	 * @return true nếu hợp lệ, false nếu không hợp lệ
	 */
	public static boolean checkEndDate(String endDate, String startDate) {
		boolean check = false;
		int[] arrStartDate = toArrayInteger(startDate);
		int[] arrEndDate = toArrayInteger(endDate);

		int startYear = arrStartDate[0];
		int startMonth = arrStartDate[1];
		int startDay = arrStartDate[2];

		int endYear = arrEndDate[0];
		int endMonth = arrEndDate[1];
		int endDay = arrEndDate[2];

		if (endYear > startYear) {
			check = true;
		} else if (endYear == startYear && endMonth > startMonth) {
			check = true;
		} else if (endYear == startYear && endMonth == startMonth && endDay > startDay) {
			check = true;
		}
		return check;
	}

	/**
	 * Hàm set giá trị cho các hạng mục selectbox ở màn hình ADM003
	 * 
	 * @param req
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static void setDataLogic(HttpServletRequest req) throws ClassNotFoundException, SQLException {

		// Khởi tạo đối tượng mstGroupLogicImpl
		MstGroupLogic mstGroupLogicImpl = new MstGroupLogicImpl();
		// Khởi tạo list danh sách nhóm hiển thị
		List<MstGroupBean> listMstGroup = mstGroupLogicImpl.getAllMstGroup();
		// Khởi tạo đối tượng mstJapanLogicImpl
		MstJapanLogic mstJapanLogicImpl = new MstJapanLogicImpl();
		// Khởi tạo list danh sách mstJapan hiển thị
		List<MstJapanBean> listMstJapan = mstJapanLogicImpl.getAllMstJapan();
		// Khởi tạo list năm
		List<Integer> listYear = getListYear(1900, Common.getYearNow());
		// Khởi tạo list tháng
		List<Integer> listYearEnd = getListYear(1900, Common.getYearNow() + 1);
		List<Integer> listMonth = getListMonth();
		// Khởi tạo list ngày
		List<Integer> listDay = getListDay();
		// set listMstGroup lên request
		req.setAttribute("listMstGroup", listMstGroup);
		// set listMstJapan lên request
		req.setAttribute("listMstJapan", listMstJapan);
		// set listYear lên request
		req.setAttribute("listYear", listYear);
		// set listYearEnd len request
		req.setAttribute("listYearEnd", listYearEnd);
		// set listMonth lên request
		req.setAttribute("listMonth", listMonth);
		// set listDay lên request
		req.setAttribute("listDay", listDay);

	}

}
