/**
 * copy right luvina
 */
package manageuser.utils;

/**
 * Class chứa các biến hằng số của Project
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class Constant {
	// Đường dẫn đến các file properties
	public static final String PROPERTIES_DATABASE_PATH = "/manageuser/properties/Database.properties";
	public static final String PROPERTIES_MESSAGE_PATH = "/manageuser/properties/Message.properties";
	public static final String PROPERTIES_LIMIT_PATH = "/manageuser/properties/Limit.properties";
	public static final String PROPERTIES_ERROR_MESSAGE_PATH = "/manageuser/properties/ErrorMessage.properties";

	// Đường dẫn đến file jsp
	public static final String JSP_ADM001 = "/jsp/ADM001.jsp";
	public static final String JSP_ADM002 = "/jsp/ADM002.jsp";
	public static final String JSP_ADM003 = "/jsp/ADM003.jsp";
	public static final String JSP_ADM004 = "/jsp/ADM004.jsp";
	public static final String JSP_ADM005 = "/jsp/ADM005.jsp";
	public static final String JSP_ADM006 = "/jsp/ADM006.jsp";
	public static final String JSP_SYSTEM_ERRPOR = "/jsp/System_Error.jsp";

	// Đường dẫn đến trang login
	public static final String LOGIN = "/login.do";
	// Đường dẫn đến trang list User
	public static final String LISTUSER_URL = "/listUser.do";
	public static final String TYPE_MESSAGE = "typeMessage";
	// Đường dẫn đến trang thông báo ADM006
	public static final String SUCCESS_URL = "/Success.do";
	// Đường dẫn đến trang lỗi
	public static final String SYSTEM_ERRORS = "/SystemError.do";
	// Đường dẫn đến trang add user confirm
	public static final String ADD_USER_CONFIRM = "/AddUserConfirm.do";
	// Đường dẫn đến trang edit user confirm
	public static final String EDIT_USER_CONFIRM = "/EditUserConfirm.do";

	public static final String ERR001_LOGIN_NAME = "ERR001_LOGINNAME";
	public static final String ER001_PASSWORD = "ER001_PASSWORD";
	public static final String ER016 = "ER016";
	public static final String DATABASE = "pro_manageuser_nguyenquanganh";
	public static final String PASSWORD = "password";
	public static final String TYPE = "type";
	public static final String SEARCH = "search";
	public static final String BACK = "back";
	public static final String VALIDATE = "validate";
	public static final String DEFAULT = "default";
	public static final String SORT = "sort";
	public static final String SORT_TYPE = "sortType";
	public static final String SORT_VALUE = "sortValue";
	public static final String PAGING = "paging";
	public static final int CURRENT_PAGE_DEFAULT = 1;
	public static final int DEFAULT_GROUP_ID = 0;
	public static final String DEFAULT_FULL_NAME = "";
	public static final String SORT_ASC = "ASC";
	public static final String SORT_DESC = "DESC";
	public static final String SORT_TYPE_DEFAULT = "fullName";
	public static final String SORT_TYPE_FULLNAME = "fullName";
	public static final String SORT_TYPE_CODE_LEVEL = "codeLevel";
	public static final String SORT_TYPE_END_DATE = "enddate";
	public static final String SORT_VALUE_DEFAULT = "ASC";
	public static final int USER_ID_DEFAULT = 0;
	public static final int DELAULT_OFFSET = 0;
	public static final int DELAULT_GROUP = 0;
	public static final int TOTAL_PAGE_DEFAULT = 0;
	public static final String CHECK = "check";
	public static final String KEY = "key";

	// Các câu thông báo lỗi ER
	public static final String ERR001_LOGINNAME = "ERR001_LOGINNAME";
	public static final String ER019_LOGINNAME = "ER019_LOGINNAME";
	public static final String ER007_LOGINNAME = "ER007_LOGINNAME";
	public static final String ER003_LOGINNAME = "ER003_LOGINNAME";
	public static final String ER002_GROUP = "ER002_GROUP";
	public static final String ER004_GROUP = "ER004_GROUP";
	public static final String ER001_FULLNAME = "ER001_FULLNAME";
	public static final String ER006_FULLNAME = "ER006_FULLNAME";
	public static final String ER009_FULLNAME_KANA = "ER009_FULLNAME_KANA";
	public static final String ER006_FULLNAME_KANA = "ER006_FULLNAME_KANA";
	public static final String ER011_BIRTHDAY = "ER011_BIRTHDAY";
	public static final String ER001_EMAIL = "ER001_EMAIL";
	public static final String ER006_EMAIL = "ER006_EMAIL";
	public static final String ER005_EMAIL = "ER005_EMAIL";
	public static final String ER003_EMAIL = "ER003_EMAIL";
	public static final String ER001_TEL = "ER001_TEL";
	public static final String ER005_TEL = "ER005_TEL";
	public static final String ER001_PASS = "ER001_PASS";
	public static final String ER008_PASS = "ER008_PASS";
	public static final String ER007_PASS = "ER007_PASS";
	public static final String ER0017_REPASS = "ER0017_REPASS";
	public static final String ER004_CODELEVEL = "ER004_CODELEVEL";
	public static final String ER011_STARTDATE = "ER011_STARTDATE";
	public static final String ER011_ENDDATE = "ER011_ENDDATE";
	public static final String ER012_ENDDATE = "ER012_ENDDATE";
	public static final String ER001_TOTAL = "ER001_TOTAL";
	public static final String ER018_TOTAL = "ER018_TOTAL";
	public static final String ER006_TOTAL = "ER006_TOTAL";
	public static final String ER015 = "ER015";
	public static final String ER013 = "ER013";
	public static final String ER020 = "ER020";

	// Phần các câu thông báo MSG
	public static final String MSG001 = "MSG001";
	public static final String MSG002 = "MSG002";
	public static final String MSG003 = "MSG003";
	public static final String MSG004 = "MSG004";
	public static final String MSG005 = "MSG005";

	// Thông số giá trị name của các trường ở jsp
	public static final String LOGIN_NAME = "loginName";
	public static final String FULLNAME = "fullName";
	public static final String FULLNAME_KANA = "fullNameKana";
	public static final String EMAIL = "email";
	public static final String TEL = "tel";
	public static final String PASS_WORD = "pass";
	public static final String REPASSWORD = "rePass";
	public static final String CODELEVEL = "codeLevel";
	public static final String ENDDATE = "enddate";
	public static final String GROUPID = "groupId";
	public static final String TOTAL = "total";
	public static final String BIRTH_YEAR = "birthyear";
	public static final String BIRTH_MONTH = "birthmonth";
	public static final String BIRTH_DAY = "birthday";
	public static final String START_YEAR = "startyear";
	public static final String START_MONTH = "startmonth";
	public static final String START_DAY = "startday";
	public static final String END_YEAR = "endyear";
	public static final String END_MONTH = "endmonth";
	public static final String END_DAY = "endday";
	public static final String USER_ID = "userId";
	public static final String USER_INFOR = "userInfor";
	public static final String MESSAGE_MSG004 = "messageMSG004";
	public static final String GROUP_ID = "group_id";
	public static final String MESSAGE = "message";
	public static final String ERROR_MESSAGE = "errorMessage";

	// Thông số của các key trong file database.properties
	public static final String DRIVER = "DRIVER";
	public static final String URL = "URL";
	public static final String USER = "USER";
	public static final String PASS = "PASS";

	// Phần set lên request và session cho ADM002
	public static final String LIMIT_PAGE = "limitPage";
	public static final String CURRENT_GROUP = "currentGroup";
	public static final String TOTAL_PAGE = "totalPage";
	public static final String LIST_MSTGROUP = "listMstGroup";
	public static final String LIST_USER_INFOR = "listUserInfor";
	public static final String CURRENT_PAGE = "currentPage";
	public static final String SOFT_BY_FULL_NAME = "softByFullName";
	public static final String SOFT_BY_CODE_LEVEL = "softByCodeLevel";
	public static final String SOFT_BY_END_DATE = "softByEnddate";
	public static final String LIST_PAGING = "listPaging";
	public static final String EMPTY = "";
	public static final int GROUP_ID_DEFAULT = 0;
	public static final String CODE_LEVEL_DEFAULT = "0";

	// Thông số các trường trong DB
	public static final String GROUP_ID_DB = "group_id";
	public static final String GROUP_NAME_DB = "group_name";
	public static final String USER_ID_DB = "user_id";
	public static final String LOGIN_NAME_DB = "login_name";
	public static final String FULL_NAME_DB = "full_name";
	public static final String FULL_NAME_KANA_DB = "full_name_kana";
	public static final String EMAIL_DB = "email";
	public static final String TEL_DB = "tel";
	public static final String PASSWORD_DB = "password";
	public static final String BIRTHDAY_DB = "birthday";
	public static final String RULE_DB = "rule";
	public static final String SALT_DB = "salt";
	public static final String CODE_LEVEL_DB = "code_level";
	public static final String NAME_LEVEL_DB = "name_level";
	public static final String START_DATE_DB = "start_date";
	public static final String END_DATE_DB = "end_date";
	public static final String TOTAL_DB = "total";

	// Rule admin
	public static final int RULE_ADMIN = 0;
	// Rule user
	public static final int RULE_USER = 1;

	// Tên attribute error
	public static final String LIST_ERRO = "listErro";
	public static final String LIST_ERROR = "listError";

}
