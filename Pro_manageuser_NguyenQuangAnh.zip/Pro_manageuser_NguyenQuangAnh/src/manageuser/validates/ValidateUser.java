/**
 * copy right luvina
 */
package manageuser.validates;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import manageuser.entities.UserInfo;
import manageuser.logics.MstGroupLogic;
import manageuser.logics.MstJapanLogic;
import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.MstGroupLogicImpl;
import manageuser.logics.impl.MstJapanLogicImpl;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.properties.ErrorMessageProperties;
import manageuser.utils.Common;
import manageuser.utils.Constant;

/**
 * @author NGUYEN QUANG ANH
 *
 */
public class ValidateUser {
	private List<String> listError;

	/**
	 * Hàm kiểm tra thông tin nhập vào từ màn hình ADM003
	 * 
	 * @param userInfo
	 * @return listErro 1 danh sách các lỗi
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public List<String> validateUserInfor(UserInfo userInfo) throws ClassNotFoundException, SQLException, IOException {
		// Khởi tạo list danh sách chứa mảng lỗi
		listError = new ArrayList<String>();
		if (userInfo.getUserId() == 0) {
			// Validate thông tin hạng mục LoginName
			validateLoginName(userInfo.getLoginName().trim());
			// Validate thông tin hạng mục PassWord
			validatePassWord(userInfo.getPass());
			// Validate thông tin hạng mục RePassWord
			validateRePassWord(userInfo.getRePass(), userInfo.getPass());
		}
		// Validate thông tin hạng mục Group
		validateGroup(userInfo.getGroupId());
		// Validate thông tin hạng mục FullName
		validateFullName(userInfo.getFullName().trim());
		// Validate thông tin hạng mục FullNameKana
		validateFullNameKana(userInfo.getFullNameKana());
		// Validate thông tin hạng mục BirthDay
		validateBirthDay(userInfo.getBirthday());
		// Validate thông tin hạng mục Email
		validateEmail(userInfo.getEmail(), userInfo.getUserId());
		// Validate thông tin hạng mục Tel
		validateTel(userInfo.getTel());
//		nếu chọn trình độ tiếng nhật
		if (!Constant.CODE_LEVEL_DEFAULT.equals(userInfo.getCodeLevel())) {
			// Validate thông tin hạng mục CodeLevel
			validateCodeLevel(userInfo.getCodeLevel());
			// Validate thông tin hạng mục StartDate
			validateStartDate(userInfo.getStartDate());
			// Validate thông tin hạng mục EndDate
			validateEndDate(userInfo.getEndDate(), userInfo.getStartDate());
			// Validate thông tin hạng mục Total
			validateToTal(userInfo.getTotal());
		}
		// Trả về 1 list lỗi
		return listError;
	}

	/**
	 * Hàm validate hạng mục total: ghi các mã lỗi sẽ code trong phương thức này ra
	 * 
	 * @param total
	 */
	private void validateToTal(String total) {
		// Nếu hạng mục total rỗng
		if (Common.checkEmpty(total)) {
			// add lỗi ER001 vào mảng lỗi
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER001_TOTAL));
			// Nếu hạng mục total sai format
		} else if (!Common.checkFormatTotal(total)) {
			// add lỗi ER018 vào mảng lỗi
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER018_TOTAL));
			// Nếu hạng mục total độ dài vượt quá maxLength
		} else if (Common.checkMaxLength(total, 9)) {
			// add lỗi ER006 vào mảng lỗi
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER006_TOTAL));
		}
	}

	/**
	 * Hàm validate hạng mục enddate
	 */
	private void validateEndDate(String endDate, String startDate) {
		if (!Common.checkDate(endDate)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER011_ENDDATE));
		} else if (!Common.checkEndDate(endDate, startDate)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER012_ENDDATE));
		}
	}

	/**
	 * Hàm validate hạng mục startdate
	 * 
	 * @param startDate
	 */
	private void validateStartDate(String startDate) {
		if (!Common.checkDate(startDate)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER011_STARTDATE));
		}
	}

	/**
	 * Hàm validate hạng mục codelevel
	 * 
	 * @param codeLevel
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	private void validateCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException, IOException {
		MstJapanLogic mstJapanLogicImpl = new MstJapanLogicImpl();
		if (!mstJapanLogicImpl.checkExistCodeLevel(codeLevel)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER004_CODELEVEL));
		}

	}

	/**
	 * Hàm validate hạng mục confirm password
	 * 
	 * @param rePass
	 * @param pass
	 */
	private void validateRePassWord(String rePass, String pass) {
		if (!rePass.equals(pass)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER0017_REPASS));
		}

	}

	/**
	 * Hàm validate hạng mục password
	 * 
	 * @param pass
	 * @throws UnsupportedEncodingException
	 */
	private void validatePassWord(String pass) throws UnsupportedEncodingException {
		if (Common.checkEmpty(pass)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER001_PASS));
		} else if (!Common.checkCharacterOneByte(pass)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER008_PASS));
		} else if (Common.checkLength(pass, 5, 15)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER007_PASS));
		}

	}

	/**
	 * Hàm validate hạng mục tel
	 * 
	 * @param tel
	 */
	private void validateTel(String tel) {
		if (Common.checkEmpty(tel)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER001_TEL));
		} else if (!Common.checkFormatTel(tel)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER005_TEL));
		}

	}

	/**
	 * Hàm validate hạng mục email
	 * 
	 * @param email
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	private void validateEmail(String email, int userId) throws ClassNotFoundException, SQLException, IOException {
		TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
		if (Common.checkEmpty(email)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER001_EMAIL));
		} else if (Common.checkMaxLength(email, 255)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER006_EMAIL));
		} else if (!Common.checkFormatEmail(email)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER005_EMAIL));
		} else if (tblUserLogicImpl.checkExistEmail(email, userId)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER003_EMAIL));
		}

	}

	/**
	 * Hàm validate hạng mục birthday
	 * 
	 * @param birthday
	 */
	private void validateBirthDay(String birthday) {
		if (!Common.checkDate(birthday)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER011_BIRTHDAY));
		}

	}

	/**
	 * Hàm validate hạng mục fullNameKana
	 * 
	 * @param fullNameKana
	 */
	private void validateFullNameKana(String fullNameKana) {
		if (fullNameKana != Constant.EMPTY) {
			if (!Common.checkKana(fullNameKana)) {
				listError.add(ErrorMessageProperties.getValueByKey(Constant.ER009_FULLNAME_KANA));
			} else if (Common.checkMaxLength(fullNameKana, 255)) {
				listError.add(ErrorMessageProperties.getValueByKey(Constant.ER006_FULLNAME_KANA));
			}
		}
	}

	/**
	 * Hàm validate hạng mục fullName
	 * 
	 * @param fullName
	 */
	private void validateFullName(String fullName) {
		if (Common.checkEmpty(fullName)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER001_FULLNAME));
		} else if (Common.checkMaxLength(fullName, 255)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER006_FULLNAME));
		}

	}

	/**
	 * Hàm validate hạng mục group
	 * 
	 * @param groupId
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	private void validateGroup(int groupId) throws ClassNotFoundException, SQLException, IOException {
		MstGroupLogic mstGroupLogicImpl = new MstGroupLogicImpl();
		if (Common.checkNoSelectSelectbox(groupId)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER002_GROUP));
		} else if (mstGroupLogicImpl.checkExistGroupName(groupId)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER004_GROUP));
		}

	}

	/**
	 * Hàm validate hạng mục loginName
	 * 
	 * @param loginName
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	private void validateLoginName(String loginName) throws ClassNotFoundException, SQLException, IOException {
		TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
		// Nếu hạng mục loginName rỗng
		if (Common.checkEmpty(loginName)) {
			// add lỗi ERR001_LOGIN_NAME vào mảng lỗi
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ERR001_LOGIN_NAME));
			// Nếu hạng mục loginName sai format
		} else if (!Common.checkFormatLoginName(loginName)) {
			// add lỗi ER019_LOGINNAME vào mảng lỗi
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER019_LOGINNAME));
		} else if (Common.checkLength(loginName, 4, 15)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER007_LOGINNAME));
		} else if (tblUserLogicImpl.checkExistLoginName(loginName)) {
			listError.add(ErrorMessageProperties.getValueByKey(Constant.ER003_LOGINNAME));
		}

	}
}
