/**
 * copy right luvina
 */
package manageuser.validates;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;

import manageuser.logics.TblUserLogic;
import manageuser.logics.impl.TblUserLogicImpl;
import manageuser.properties.ErrorMessageProperties;
import manageuser.utils.Constant;

/**
 * Class kiểm tra đăng nhập của admind
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class LoginValidate {
	/**
	 * Ham validate login
	 * 
	 * @param loginName
	 * @param passWord
	 * @return listError danh sách các lỗi khi thực hiện login, nếu login thành công
	 *         thì listError.size() = 0
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws NoSuchAlgorithmException
	 */
	public ArrayList<String> loginValidate(String loginName, String passWord)
			throws ClassNotFoundException, SQLException, NoSuchAlgorithmException {
		// Khởi tạo 1 list lỗi
		ArrayList<String> listError = new ArrayList<String>();
		try {
			// Khởi tạo đối tượng TblUserLogicImpl
			TblUserLogic tblUserLogicImpl = new TblUserLogicImpl();
			// Nếu tên đăng nhập rỗng
			if (loginName.isEmpty()) {
				// Thêm lỗi ERR001_LOGIN_NAME vào listError
				listError.add(ErrorMessageProperties.getValueByKey(Constant.ERR001_LOGINNAME));
			}
			// Nếu password rỗng
			if (passWord.isEmpty()) {
				// Thêm lỗi ER001_PASSWORD vào listError
				listError.add(ErrorMessageProperties.getValueByKey(Constant.ER001_PASSWORD));
			}
			// Nếu listError rỗng
			if (listError.size() == 0) {
				// Nếu không trung loginName hoặc pass
				if (!tblUserLogicImpl.checkExitAdmin(loginName, passWord)) {
					// Thêm lỗi ER016 vào listError
					listError.add(ErrorMessageProperties.getValueByKey(Constant.ER016));
				}
			}
		} catch (ClassNotFoundException | SQLException | NoSuchAlgorithmException e) {
			// Ghi log lỗi
			System.out.println("LoginValidate: loginValidate " + e.getMessage());
			throw e;
		}
		// Trả về listError
		return listError;
	}
}
