/**
 * copy right luvina
 */
package manageuser.dao;

import java.sql.SQLException;

import manageuser.entities.TbldetailUserJapanBean;

/**
 * Interface thao tác với bảng tbl_detail_user_japan trong Database
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public interface TblDetailUserJapanDao extends BaseDao {
	/**
	 * Thêm một đối tượng TblDetailUserJapan
	 * 
	 * @param tbldetailUserJapanBean
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	boolean insertDetailUserJapan(TbldetailUserJapanBean tbldetailUserJapanBean)
			throws ClassNotFoundException, SQLException;

	/**
	 * Lấy về một đối tượng TblDetailUserJapan theo userId truyền vào
	 * 
	 * @return TbldetailUserJapanBean nếu có
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	TbldetailUserJapanBean getTblDetailUserJapan(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm Edit dữ liệu cho bảng TblDetailUserJapan
	 * 
	 * @param TbldetailUserJapanBean
	 * @return true nếu edit thành công, false nếu edit thất bại
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	boolean editTblDetailUserJapan(TbldetailUserJapanBean TbldetailUserJapanBean)
			throws ClassNotFoundException, SQLException;

	/**
	 * Hàm xoá một đối tượng TblDetailUserJapan
	 * 
	 * @param userId
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	boolean deleteTblDetailUserJapan(int userId) throws ClassNotFoundException, SQLException;
}
