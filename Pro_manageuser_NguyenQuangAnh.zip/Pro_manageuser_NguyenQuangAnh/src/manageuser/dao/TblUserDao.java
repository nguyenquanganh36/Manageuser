/**
 * copy right luvina
 */
package manageuser.dao;

import java.sql.SQLException;
import java.util.List;

import manageuser.entities.TblUserBean;
import manageuser.entities.UserInfo;

/**
 * Interface thao tác với bảng tblUser trong Database
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public interface TblUserDao extends BaseDao {
	/**
	 * Lấy ra các thông tin của User trong Database theo tham số loginName truyền
	 * vào
	 * 
	 * @param loginName: tên đăng nhập
	 * @return TblUserBean trả về 1 user
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public TblUserBean getUserByLoginName(String loginName) throws ClassNotFoundException, SQLException;

	/**
	 * Lấy ra danh sách User
	 * 
	 * @param offset          vị trí data cần lấy
	 * @param limit           số lượng lấy
	 * @param groupId         mã nhóm tìm kiếm
	 * @param fullName        tên tìm kiếm
	 * @param sortType        sắp xếp theo trường nào(full_name or code_level or
	 *                        end_date)
	 * @param sortByFullName  Giá trị sắp xếp của cột Tên(ASC or DESC)
	 * @param sortByCodeLevel Giá trị sắp xếp của cột Trình độ tiếng nhật(ASC or
	 *                        DESC)
	 * @param sortByEndDate   Giá trị sắp xếp của cột Ngày kết hạn(ASC or DESC)
	 * @return List<UserInfo> Danh sách User lấy được
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public List<UserInfo> getListUser(int offset, int limit, int groupID, String fullName, String softType,
			String softByFullName, String softByCodeLevel, String softByEnddate)
			throws ClassNotFoundException, SQLException;

	/**
	 * Lấy tổng số user
	 * 
	 * @param groupId  mã nhóm tìm kiếm
	 * @param fullName tên tìm kiếm
	 * @return tổng số user (int)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int getTotalUser(int groupId, String fullName) throws ClassNotFoundException, SQLException;

	/**
	 * kiểm tra xem có tồn tại loginName trong database hay không
	 * 
	 * @param loginName : loginName cần check
	 * @return 1 nếu loginName tồn tại, 0 nếu loginName không tồn tại
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public TblUserBean getTblUserByLoginName(String loginName) throws ClassNotFoundException, SQLException;

	/**
	 * Lấy về TblUserBean với email bằng email truyền vào và userId khác userId
	 * truyền vào
	 * 
	 * @param email
	 * @param userId
	 * @return đối tượng TblUserBean
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public TblUserBean getTblUserByEmail(String email, int userId)
			throws ClassNotFoundException, SQLException;

	/**
	 * Thêm một đối tượng TblUser vào Database
	 * 
	 * @param tblUser
	 * @return userId nếu thêm thành công, 0 nếu thêm thất bại
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int insertTblUser(TblUserBean tblUser) throws ClassNotFoundException, SQLException;
	/**
	 * Hàm lấy về 1 TblUserBean theo userId truyền vào
	 * 
	 * @param userId
	 * @return TblUserBean
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public TblUserBean getTblUserById(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy ra 1 userInfor theo userId truyền vào
	 * 
	 * @param userId
	 * @return userInfor
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public UserInfo getUserInforById(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm edit thông tin của User vào bảng TblUser
	 * 
	 * @param tblUser
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public boolean editTblUser(TblUserBean tblUser) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy ra rule của user theo userId truyền vào
	 * 
	 * @param userId
	 * @return null nếu không tồn tại rule, 0 nếu user là Admin, 1 nếu user là user
	 *         thường
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public String getRuleUserById(int userId) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm xoá 1 đối tượng TblUser ra khỏi DB
	 * 
	 * @param userId : userId của đối tượng cần xoá
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public boolean deleteUser(int userId) throws ClassNotFoundException, SQLException;
}
