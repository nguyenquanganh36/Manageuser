/**
 * copy right luvina
 */
package manageuser.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import manageuser.entities.MstJapanBean;

/**
 * Class thao tác với Database
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public interface MstJapanDao {
	/**
	 * Hàm lấy ra danh sách trình độ tiếng Nhật trong bảng mst_japan
	 * 
	 * @return listMstJapan : danh sách trình độ tiếng Nhật
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	List<MstJapanBean> getAllMstJapan() throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy ra tên namelevel theo codeLevel truyền vào
	 * 
	 * @param codeLevel mã trình độ tiếng nhật
	 * @return nameLevel tương ứng với codeLevel nếu có
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	String getNameLevelByCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy ra đối tượng MstJapanBean theo codeLevel truyền vào
	 * 
	 * @param codeLevel mã trình độ tiếng nhật
	 * @return MstJapanBean đối tượng MstJapan
	 * @throws ClassNotFoundException
	 * @throws SQLException           bắn lỗi khi không thao tác được với DB
	 * @throws IOException            bắn lỗi khi không tìm thấy Driver
	 */
	MstJapanBean getMstJapanByCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException;
}
