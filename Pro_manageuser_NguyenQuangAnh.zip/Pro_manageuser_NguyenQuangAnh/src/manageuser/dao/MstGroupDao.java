/**
 * copy right luvina
 */
package manageuser.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import manageuser.entities.MstGroupBean;

/**
 * Interface thao tác với DB bảng mst_group
 * 
 * @author LA-PM
 *
 */
public interface MstGroupDao {
	/**
	 * Hàm lấy tất cả các giá trị có trong bảng mst_group
	 * 
	 * @return listGroup danh sách các group
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	List<MstGroupBean> getAllMstGroup() throws ClassNotFoundException, SQLException;

	/**
	 * Hàm lấy tên groupName theo groupId truyền vào
	 * 
	 * @param groupId : giá trị truyền vào để tìm kiếm
	 * @return groupName nếu groupId tồn tại trong DB, null nếu groupId khong tồn
	 *         tại trong DB
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	MstGroupBean getMstGroupById(int groupId) throws ClassNotFoundException, SQLException;
}
