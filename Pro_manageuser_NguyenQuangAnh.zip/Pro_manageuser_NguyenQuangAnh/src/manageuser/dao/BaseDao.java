/**
 * copy right luvina
 */
package manageuser.dao;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Thao tác với Database
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public interface BaseDao {
	/**
	 * Thiết lập kết nối tới Database
	 * 
	 * @return conn
	 * @throws SQLException
	 */
	public Connection getConnection() throws ClassNotFoundException, SQLException;

	/**
	 * Truyền 1 connection để sử dụng trong class
	 * 
	 * @param connection: connection truyền vào
	 */
	public void setConnection(Connection conn);

	/**
	 * Đóng kết nối
	 * 
	 * @throws SQLException
	 */
	void closeConnection() throws SQLException;

}
