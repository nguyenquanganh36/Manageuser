/**
 * copy right luvina
 */
package manageuser.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import manageuser.dao.MstJapanDao;
import manageuser.entities.MstJapanBean;
import manageuser.utils.Constant;

/**
 * @author NGUYEN QUANG ANH
 *
 */
public class MstJapanDaoImpl extends BaseDaoImpl implements MstJapanDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see manageuser.dao.MstJapanDao#getAllMstJapan()
	 */
	@Override
	public List<MstJapanBean> getAllMstJapan() throws ClassNotFoundException, SQLException {
		// Tạo 1 list chứa các Mstjapan lấy được từ DB
		List<MstJapanBean> listMstJapan = new ArrayList<MstJapanBean>();
		try {
			// thực hiện kết nối tới DB
			getConnection();
			// Khởi tạo đối tượng StringBuilder để lưu câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT * FROM mst_japan ORDER BY code_level ASC ");
			// Tạo đối tượng để thao tác với sql
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// Thực thi câu truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MstJapanBean mstJapanBean = new MstJapanBean();
				mstJapanBean.setCodeLevel(rs.getString(Constant.CODE_LEVEL_DB));
				mstJapanBean.setNameLevel(rs.getString(Constant.NAME_LEVEL_DB));
				listMstJapan.add(mstJapanBean);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi log lại
			System.out.println("MstJapanDaoImpl  :  getAllMstJapan " + e.getMessage());
			// ném ngoại lệ
			throw e;
		} finally {
			// đóng kết nối
			closeConnection();
		}
		return listMstJapan;
	}

	@Override
	public String getNameLevelByCodeLevel(String codeLevel) throws ClassNotFoundException, SQLException {
		String nameLevel = Constant.EMPTY;
		try {
			// Thiết lập kết nối tới DB
			getConnection();
			if (conn != null) {
				// khởi tạo câu lệnh truy vấn sql
				String sql = "select name_level from mst_japan where code_level = ? ";
				// sử dụng PreparedStatement
				PreparedStatement preparedStatement = conn.prepareStatement(sql);
				// set gia trị
				preparedStatement.setString(1, codeLevel);
				// thực thi câu truy vấn
				ResultSet resultSet = preparedStatement.executeQuery();
				if (resultSet != null) {
					while (resultSet.next()) {
						nameLevel = resultSet.getString(Constant.NAME_LEVEL_DB);
					}
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// ném ngoại lệ
			throw e;
		} finally {
			// đóng két nối
			closeConnection();
		}
		return nameLevel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see manageuser.dao.MstJapanDao#getMstJapanByCodeLevel(java.lang.String)
	 */
	@Override
	public MstJapanBean getMstJapanByCodeLevel(String codeLevel)
			throws ClassNotFoundException, SQLException {
		// Start fix bug ID 12 – AnhNQ 2019/12/26
		MstJapanBean mstJapan = null;
		try {
			// Thiết lập kết nối tới DB
			getConnection();
			if (conn != null) {
				// khởi tạo câu lệnh truy vấn sql
				String sql = "select * from mst_japan where code_level = ? ";
				// sử dụng PreparedStatement
				PreparedStatement preparedStatement = conn.prepareStatement(sql);
				// set gia trị
				preparedStatement.setString(1, codeLevel);
				// thực thi câu truy vấn
				ResultSet resultSet = preparedStatement.executeQuery();

				if (resultSet != null) {
					while (resultSet.next()) {
						mstJapan = new MstJapanBean();
						// End fix bug ID 12 – AnhNQ 2019/12/26
						mstJapan.setCodeLevel(resultSet.getString(Constant.CODE_LEVEL_DB));
						mstJapan.setNameLevel(resultSet.getString(Constant.NAME_LEVEL_DB));
					}
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			// ném ngoại lệ
			throw e;
		} finally {
			// đóng kết nối
			closeConnection();
		}
		// Trả về đối tượng mstJapan
		return mstJapan;
	}

}
