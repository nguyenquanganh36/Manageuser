/**
 * copy right luvina
 */
package manageuser.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import manageuser.dao.MstGroupDao;
import manageuser.entities.MstGroupBean;
import manageuser.utils.Constant;

/**
 * @author LA-PM
 *
 */
public class MstGroupDaoImpl extends BaseDaoImpl implements MstGroupDao {

	@Override
	public List<MstGroupBean> getAllMstGroup() throws ClassNotFoundException, SQLException {
		// Tạo 1 listMst để chứa các nhóm lấy được từ DB
		List<MstGroupBean> listMstGroup = new ArrayList<MstGroupBean>();
		try {
			getConnection();
			// khởi tạo đối tượng StringBuilder để lưu câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT * FROM mst_group ORDER BY group_id ASC ");
			// tạo đối tượng để thao tác với sql
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// thực hiện truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MstGroupBean mstGroupBean = new MstGroupBean();
				mstGroupBean.setGroupId(rs.getInt(Constant.GROUP_ID_DB));
				mstGroupBean.setGroupName(rs.getString(Constant.GROUP_NAME_DB));
				listMstGroup.add(mstGroupBean);
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			closeConnection();
		}
		return listMstGroup;
	}

	@Override
	public MstGroupBean getMstGroupById(int groupId) throws ClassNotFoundException, SQLException {
		MstGroupBean mstGroup = null;
		try {
			// Thiết lập kết nối tới DB
			getConnection();
			if (conn != null) {
				// Khởi tạo câu truy vấn
				String sql = "SELECT * from mst_group where group_id = ?;";
				// Tạo đối tượng PreparedStatement
				PreparedStatement ps = conn.prepareStatement(sql);
				// set giá trị
				ps.setInt(1, groupId);
				// Thực thi truy vấn
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					mstGroup = new MstGroupBean();
					mstGroup.setGroupId(rs.getInt(Constant.GROUP_ID_DB));
					mstGroup.setGroupName(rs.getString(Constant.GROUP_NAME_DB));
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			closeConnection();
		}
		return mstGroup;
	}
}
