/**
 * copy right luvina
 */
package manageuser.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import manageuser.dao.TblDetailUserJapanDao;
import manageuser.entities.TbldetailUserJapanBean;
import manageuser.utils.Constant;

/**
 * Thao tác với bảng TblDetailUserJapan trong DB
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class TblDetailUserJapanDaoImpl extends BaseDaoImpl implements TblDetailUserJapanDao {

	@Override
	public boolean insertDetailUserJapan(TbldetailUserJapanBean tbldetailUserJapanBean)
			throws ClassNotFoundException, SQLException{
		// Tao 1 bien check
		boolean check = false;
		try {
			// Khởi tạo 1 biến chỉ số
			int index = 1;
			// tạo câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tbl_detail_user_japan (user_id, code_level, start_date, end_date, total) ");
			sql.append("VALUES (?, ?, ?, ?, ?);");
			// sử dụng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// set các giá trị
			ps.setInt(index++, tbldetailUserJapanBean.getUserId());
			ps.setString(index++, tbldetailUserJapanBean.getCodeLevel());
			ps.setString(index++, tbldetailUserJapanBean.getStartDate());
			ps.setString(index++, tbldetailUserJapanBean.getEndDate());
			ps.setString(index++, tbldetailUserJapanBean.getTotal());
			// Thực thi truy vấn
			int result = ps.executeUpdate();
			if (result > 0) {
				check = true;
			}
		} catch (SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		}
		return check;
	}

	@Override
	public TbldetailUserJapanBean getTblDetailUserJapan(int userId)
			throws ClassNotFoundException, SQLException{
		// Khởi tạo đối tượng TbldetailUserJapanBean
		TbldetailUserJapanBean tbldetailUserJapanBean = null;
		try {
			// Thiết lập kết nối tới Database
			getConnection();
			// tạo câu truy vấn
			String sql = "SELECT * FROM tbl_detail_user_japan WHERE user_id = ?";
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql);
			// tạo 1 biến chỉ số
			int index = 1;
			// set giá trị
			ps.setInt(index++, userId);
			// Thực thi truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				tbldetailUserJapanBean = new TbldetailUserJapanBean();
				tbldetailUserJapanBean.setUserId(rs.getInt(Constant.USER_ID_DB));
			}
		} catch (SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		}finally {
			closeConnection();
		}
		return tbldetailUserJapanBean;
	}

	@Override
	public boolean editTblDetailUserJapan(TbldetailUserJapanBean TbldetailUserJapanBean)
			throws ClassNotFoundException, SQLException{
		// Khởi tạo biến check
		boolean check = false;
		try {
			// Khởi tạo 1 biến chỉ số
			int index = 1;
			// Tạo câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE tbl_detail_user_japan SET code_level = ? , start_date = ? , ");
			sql.append(" end_date = ? , total = ? ");
			sql.append(" WHERE user_id = ? ");
			// Sử dụng đối tượng preparedStatement
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// set các giá trị
			ps.setString(index++, TbldetailUserJapanBean.getCodeLevel());
			ps.setString(index++, TbldetailUserJapanBean.getStartDate());
			ps.setString(index++, TbldetailUserJapanBean.getEndDate());
			ps.setString(index++, TbldetailUserJapanBean.getTotal());
			ps.setInt(index++, TbldetailUserJapanBean.getUserId());
			// Thực thi truy vấn
			int result = ps.executeUpdate();
			if (result > 0) {
				check = true;
			}
		} catch (SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		}
		return check;
	}

	@Override
	public boolean deleteTblDetailUserJapan(int userId) throws SQLException{
		// Khởi tạo 1 biến check
		boolean check = false;
		try {
			// Tạo câu truy vấn
			String sql = "DELETE FROM tbl_detail_user_japan WHERE user_id = ? ;";
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql);
			// set giá trị
			ps.setInt(1, userId);
			// Thực thi truy vấn
			int result = ps.executeUpdate();
			if (result > 0) {
				check = true;
			}
		} catch (SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		}
		return check;
	}

}
