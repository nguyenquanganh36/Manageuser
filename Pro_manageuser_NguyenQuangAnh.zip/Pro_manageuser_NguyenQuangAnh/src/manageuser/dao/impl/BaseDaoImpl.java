/**
 * copy right luvina
 */
package manageuser.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import manageuser.dao.BaseDao;
import manageuser.properties.DatabaseProperties;
import manageuser.utils.Constant;

/**
 * Thao tác với Database
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class BaseDaoImpl implements BaseDao {
	protected Connection conn;

	/* (non-Javadoc)
	 * @see manageuser.dao.BaseDao#getConnection()
	 */
	@Override
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		try {
			// Lấy giá trị driver
			String driver = DatabaseProperties.getValueByKey(Constant.DRIVER);
			Class.forName(driver);
			// Lấy giá trị url
			String url = DatabaseProperties.getValueByKey(Constant.URL);
			// Lấy giá trị user
			String user = DatabaseProperties.getValueByKey(Constant.USER);
			// Lấy giá trị pass
			String pass = DatabaseProperties.getValueByKey(Constant.PASS);
			// Thiết lập kết nối với Database
			conn = DriverManager.getConnection(url, user, pass);
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		}
		return conn;
	}

	@Override
	public void setConnection(Connection conn) {
		this.conn = conn;
	}

	@Override
	public void closeConnection() throws SQLException {
		try {
			if (conn != null && conn.isClosed()) {
				// Thực hiện đóng kết nối tới DB
				conn.close();
				conn = null;
			}
		} catch (SQLException e) {
			// Ghi lại log
			System.out.println("BaseDaoImpl closeConnection" + e.getMessage());
			throw e;
		}

	}

}
