/**
 * copy right luvina
 */
package manageuser.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import manageuser.dao.TblUserDao;
import manageuser.entities.TblUserBean;
import manageuser.entities.UserInfo;
import manageuser.utils.Common;
import manageuser.utils.Constant;

/**
 * Lớp thực thi interface TblUserDao
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class TblUserDaoImpl extends BaseDaoImpl implements TblUserDao {
	@Override
	public TblUserBean getUserByLoginName(String loginName) throws ClassNotFoundException, SQLException{
		TblUserBean user = null;
		// Tạo biến chỉ số
		int index = 0;
		try {
			// thiết lập kết nối tới DB
			getConnection();
			String sql = "select * from tbl_user where login_name = ? and rule = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			// set giá trị
			ps.setString(++index, loginName);
			ps.setInt(++index, Constant.RULE_ADMIN);
			// Thực hiện truy vấn
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new TblUserBean();
				user.setUserId(rs.getInt(Constant.USER_ID_DB));
				user.setGroupId(rs.getInt(Constant.GROUP_ID_DB));
				user.setLoginName(rs.getString(Constant.LOGIN_NAME_DB));
				user.setPassword(rs.getString(Constant.PASSWORD_DB));
				user.setFullName(rs.getString(Constant.FULL_NAME_DB));
				user.setFullNameKana(rs.getString(Constant.FULL_NAME_KANA_DB));
				user.setTel(rs.getString(Constant.TEL_DB));
				user.setEmail(rs.getString(Constant.EMAIL_DB));
				user.setBirthday(rs.getString(Constant.BIRTHDAY_DB));
				user.setRule(rs.getInt(Constant.RULE_DB));
				user.setSalt(rs.getString(Constant.SALT_DB));
			}

		} catch (ClassNotFoundException | SQLException e) {
			throw e;
		} finally {
			closeConnection();
		}
		return user;
	}

	@Override
	public List<UserInfo> getListUser(int offset, int limit, int groupID, String fullName, String softType,
			String softByFullName, String softByCodeLevel, String softByEnddate)
			throws ClassNotFoundException, SQLException{
		// Lấy ra các cột trong DB
		List<String> whiteList = getColumnName(Constant.DATABASE);
		List<UserInfo> listUser = new ArrayList<UserInfo>();
		try {
			getConnection();
			if (conn != null) {
				// tạo câu truy vấn
				StringBuilder sql = new StringBuilder();
				// tạo biến chỉ số
				int index = 0;
				sql.append(
						"select u.user_id, u.full_name, u.birthday, u.email, u.tel, g.group_name, j.name_level, d.end_date, d.total ")
						.append("from tbl_user as u	inner join mst_group as g on g.group_id = u.group_id ")
						.append("left join (tbl_detail_user_japan as d inner join mst_japan as j on j.code_level = d.code_level) ")
						.append("on d.user_id = u.user_id where u.rule = 1 ");
				// Nếu mã nhóm khác 0
				if (groupID > 0) {
					// thêm điều kiện mã nhóm vào câu sql
					sql.append(" and g.group_id = ? ");
				}
				if (fullName.length() > 0) {
					// thêm điều kiện tìm kiếm theo tên
					sql.append(" and u.full_name like ? ");
				}
				if (Common.checkExitColumn(whiteList, Constant.FULL_NAME_DB)
						&& Common.checkExitColumn(whiteList, Constant.CODE_LEVEL_DB)
						&& Common.checkExitColumn(whiteList, Constant.END_DATE_DB)) {
					// nếu cột sort là cột fullName
					if (softType.equals(Constant.FULLNAME)) {
						// thêm điều kiện vào câu sql
						sql.append("ORDER BY u.full_name " + softByFullName);
						sql.append(", j.code_level " + softByCodeLevel);
						sql.append(", d.end_date " + softByEnddate);
					}
					// nếu cột sort là cột codeLevel
					if (softType.equals(Constant.CODELEVEL)) {
						// thêm điều kiện vào câu sql
						sql.append("ORDER BY j.code_level " + softByCodeLevel);
						sql.append(", u.full_name " + softByFullName);
						sql.append(", d.end_date " + softByEnddate);
					}
					// nếu cột sort là cột enddate
					if (softType.equals(Constant.ENDDATE)) {
						// thêm điều kiện vào câu sql
						sql.append("ORDER BY d.end_date " + softByEnddate);
						sql.append(", u.full_name " + softByFullName);
						sql.append(", j.code_level " + softByCodeLevel);
					}
				}
				sql.append(" LIMIT ? OFFSET ? ");
				PreparedStatement ps = conn.prepareStatement(sql.toString());
				if (groupID > 0 && !fullName.isEmpty()) {
					ps.setInt(++index, groupID);
					ps.setString(++index, "%" + fullName);
				} else if (groupID > 0 && fullName.isEmpty()) {
					ps.setInt(++index, groupID);
				} else if (groupID == 0 && !fullName.isEmpty()) {
					ps.setString(++index, "%" + fullName);
				} else {

				}
				ps.setInt(++index, limit);
				ps.setInt(++index, offset);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					UserInfo userInfo = new UserInfo();
					userInfo.setUserId(rs.getInt(Constant.USER_ID_DB));
					userInfo.setFullName(rs.getString(Constant.FULL_NAME_DB));
					userInfo.setBirthday(rs.getString(Constant.BIRTHDAY_DB));
					userInfo.setEmail(rs.getString(Constant.EMAIL_DB));
					userInfo.setTel(rs.getString(Constant.TEL_DB));
					userInfo.setGroupName(rs.getString(Constant.GROUP_NAME_DB));
					userInfo.setEndDate(rs.getString(Constant.END_DATE_DB));
					userInfo.setNameLevel(rs.getString(Constant.NAME_LEVEL_DB));
					userInfo.setTotal(rs.getString(Constant.TOTAL_DB));
					listUser.add(userInfo);
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Lỗi TbluserDaoImpl.getListUsers(): " + e.getMessage());
			throw e;
		} finally {
			closeConnection();
		}
		return listUser;
	}

	@Override
	public int getTotalUser(int groupId, String fullName) throws ClassNotFoundException, SQLException{
		// Khởi tạo biến đếm tổng số user
		int totalUser = 0;
		try {
			// Mở kết nối DB
			getConnection();
			// tao cau truy van
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT COUNT(user_id)  FROM tbl_user u ");
			sql.append("INNER JOIN mst_group g ON u.group_id = g.group_id WHERE u.rule = 1");
			// Nếu mã nhóm khác 0
			if (groupId > 0) {
				// them dieu kien ma nhom vao cau sql
				sql.append(" and g.group_id = ? ");
			}
			if (fullName.length() > 0) {
				// thêm điều kiện tìm kiếm theo tên
				sql.append(" and u.full_name like ? ");
			}
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			int index = 0;
			if (groupId > 0) {
				ps.setInt(++index, groupId);
			}
			if (fullName.length() > 0) {
				ps.setString(++index, "%" + fullName);
			}
			// thực thi câu truy vấn
			ResultSet rs = ps.executeQuery();
			// lay du lieu trong bang
			while (rs.next()) {
				totalUser = rs.getInt(1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// ghi lại log
			System.out.println("TblUserDaoImpl: getTotalUsers: " + e.getMessage());
		} finally {
			closeConnection();
		}
		return totalUser;
	}

	/**
	 * Ham lay ra ten tat ca cac cot trong DB
	 * 
	 * @param tableName
	 * @return whiteList Danh sach ten cot co trong DB
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private ArrayList<String> getColumnName(String tableName) throws ClassNotFoundException, SQLException {
		ArrayList<String> whiteList = new ArrayList<>();
		try {
//			Mở connection
			getConnection();
//			Tạo câu truy vấn
			String sql = "select column_name from information_schema.columns where table_schema = ?";
			// Tạo một đối tượng PreparedStatement để gửi các câu lệnh SQL được tham số hóa
			// đến cơ sở dữ liệu.
			PreparedStatement ps = conn.prepareStatement(sql);
			// Set thêm giá trị cho câu truy vấn
			ps.setString(1, tableName);
//			Thực thi câu truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
//				add kết quả vào whiteList
				whiteList.add(rs.getString(1));
			}
		} catch (ClassNotFoundException | SQLException e) {
//			Ghi lại log
			System.out.println("TblUserDaoImpl  getColumnName" + e.getMessage());
//			Ném ngoại lệ
			throw e;
		} finally {
//			Đóng kết nối
			closeConnection();
		}
//		Trả về danh sách các tên trường trong Database
		return whiteList;
	}

	@Override
	public TblUserBean getTblUserByLoginName(String loginName)
			throws ClassNotFoundException, SQLException{
		// Khởi tạo một biến đếm
		TblUserBean tblUserBean = null;
		try {
			// Thiết lập kết nối tới DB
			getConnection();
			// Tạo câu truy vấn
			String sql = "SELECT * from tbl_user where login_name = ?";
			// gọi đối tượng pre
			PreparedStatement ps = conn.prepareStatement(sql);
			// Tao bien index
			int index = 1;
			ps.setString(index++, loginName);
			// Thực thi truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				tblUserBean = new TblUserBean();
				tblUserBean.setUserId(rs.getInt(Constant.USER_ID_DB));
				tblUserBean.setPassword(rs.getString(Constant.PASSWORD_DB));
			}
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			// Dong ket noi toi DB
			closeConnection();
		}
		return tblUserBean;
	}

	@Override
	public TblUserBean getTblUserByEmail(String email, int userId)
			throws ClassNotFoundException, SQLException{
		// Khởi tạo đối tượng TblUser
		TblUserBean TblUser = null;
		try {
			// Thiết lập kết nối tới DB
			getConnection();
			// Tạo câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append("Select * from tbl_user where email = ?");
			if (userId > 0) {
				sql.append(" and user_id != ?");
			}
			// Gọi đối tượng Preparestatement
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// Tạo một biến chỉ số
			int index = 1;
			ps.setString(index++, email);
			if (userId > 0) {
				ps.setInt(index++, userId);
			}
			// Thực thi truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				TblUser = new TblUserBean();
				TblUser.setEmail(rs.getString(Constant.EMAIL_DB));
			}
		} catch (ClassNotFoundException | SQLException e) {
			// Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			// Dong ket noi toi DB
			closeConnection();
		}
		return TblUser;
	}

	@Override
	public int insertTblUser(TblUserBean tblUser) throws ClassNotFoundException, SQLException{
		// Khởi tạo biến trả về
		int userId = 0;
		try {
			// Tạo câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append(
					"INSERT INTO tbl_user (group_id,login_name,password,full_name,full_name_kana,email,tel,birthday,rule,salt)");
			sql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			// Tạo biến chỉ số
			int index = 1;
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			// set giá trị
			ps.setInt(index++, tblUser.getGroupId());
			ps.setString(index++, tblUser.getLoginName());
			ps.setString(index++, tblUser.getPassword());
			ps.setString(index++, tblUser.getFullName());
			ps.setString(index++, tblUser.getFullNameKana());
			ps.setString(index++, tblUser.getEmail());
			ps.setString(index++, tblUser.getTel());
			ps.setString(index++, tblUser.getBirthday());
			ps.setInt(index++, tblUser.getRule());
			ps.setString(index++, tblUser.getSalt());
			// Thực thi truy vấn
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
			if (rs.next()) {
				userId = rs.getInt(1);
			}
		} catch (SQLException e) {
			// ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		}
		return userId;
	}

	@Override
	public TblUserBean getTblUserById(int userId) throws ClassNotFoundException, SQLException{
		// Khởi tạo đối tượng TblUserBean
		TblUserBean tblUserBean = null;
		try {
			// Thiết lập kết nối tới database
			getConnection();
			// Tạo câu truy vấn
			String sql = "SELECT * FROM tbl_user WHERE user_id = ? ";
			// Tạo biến chỉ số
			int index = 1;
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql);
			// set giá trị
			ps.setInt(index++, userId);
			// Thực thi truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				tblUserBean = new TblUserBean();
				tblUserBean.setUserId(rs.getInt("user_id"));
			}
		} catch (Exception e) {
			// ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			closeConnection();
		}
		return tblUserBean;
	}

	@Override
	public UserInfo getUserInforById(int userId) throws ClassNotFoundException, SQLException{
		// Khởi tạo đối tượng userInfor
		UserInfo userInfor = null;
		try {
			//
			getConnection();
			// Tạo câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append(
					"SELECT u.user_id, u.full_name,u.full_name_kana, u.login_name, u.birthday, u.email, u.tel, u.group_id, g.group_name, j.code_level, j.name_level, d.start_date, d.end_date, d.total ");
			sql.append("FROM tbl_user as u	INNER JOIN mst_group as g on g.group_id = u.group_id ");
			sql.append(
					"LEFT JOIN (tbl_detail_user_japan as d INNER JOIN mst_japan as j on j.code_level = d.code_level) ");
			sql.append("ON d.user_id = u.user_id WHERE u.user_id = ? ;");
			// Tạo biến chỉ số
			int index = 1;
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// set giá trị
			ps.setInt(index++, userId);
			// Thực thi truy vấn
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				userInfor = new UserInfo();
				userInfor.setUserId(rs.getInt(Constant.USER_ID_DB));
				userInfor.setLoginName(rs.getString(Constant.LOGIN_NAME_DB));
				userInfor.setGroupId(rs.getInt(Constant.GROUP_ID_DB));
				userInfor.setGroupName(rs.getString(Constant.GROUP_NAME_DB));
				userInfor.setFullName(rs.getString(Constant.FULL_NAME_DB));
				userInfor.setFullNameKana(rs.getString(Constant.FULL_NAME_KANA_DB));
				userInfor.setBirthday(rs.getString(Constant.BIRTHDAY_DB));
				userInfor.setEmail(rs.getString(Constant.EMAIL_DB));
				userInfor.setTel(rs.getString(Constant.TEL_DB));
				userInfor.setCodeLevel(rs.getString(Constant.CODE_LEVEL_DB));
				userInfor.setNameLevel(rs.getString(Constant.NAME_LEVEL_DB));
				userInfor.setStartDate(rs.getString(Constant.START_DATE_DB));
				userInfor.setEndDate(rs.getString(Constant.END_DATE_DB));
				userInfor.setTotal(rs.getString(Constant.TOTAL_DB));
			}
		} catch (Exception e) {
			// ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			// Đóng kết nối tới database
			closeConnection();
		}
		return userInfor;
	}

	@Override
	public boolean editTblUser(TblUserBean tblUser) throws ClassNotFoundException, SQLException{
		// Khởi tạo một biến check kiểu boolean có giá trị bằng false
		boolean check = false;
		try {
			// Tạo câu truy vấn
			StringBuilder sql = new StringBuilder();
			sql.append(
					"UPDATE tbl_user SET group_id = ?, login_name = ?, full_name = ?, full_name_kana = ?, email = ?, tel = ?, birthday = ? ");
			sql.append("WHERE user_id = ? and rule = ?");
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			// Tạo một biến chỉ số
			int index = 1;
			// set các giá trị
			ps.setInt(index++, tblUser.getGroupId());
			ps.setString(index++, tblUser.getLoginName());
			ps.setString(index++, tblUser.getFullName());
			ps.setString(index++, tblUser.getFullNameKana());
			ps.setString(index++, tblUser.getEmail());
			ps.setString(index++, tblUser.getTel());
			ps.setString(index++, tblUser.getBirthday());
			ps.setInt(index++, tblUser.getUserId());
			ps.setInt(index, 1);
			// Thực thi truy vấn
			int record = ps.executeUpdate();
			if (record > 0) {
				check = true;
			}
		} catch (Exception e) {
			// ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
//			ném ngoại lệ
			throw e;
		}
//		Trả về check
		return check;
	}

	@Override
	public String getRuleUserById(int userId) throws ClassNotFoundException, SQLException {
		// Khởi tạo 1 biến String để trả về
		String rule = null;
		try {
			// Mở kết nối tới Database
			getConnection();
			// Tạo câu truy vấn
			String sql = "SELECT rule FROM tbl_user WHERE user_id = ? ;";
			// Sử dụng đối tượng PreparedStatement
			PreparedStatement ps = conn.prepareStatement(sql);
			// set giá trị
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				rule = rs.getString(1);
			}
		} catch (Exception e) {
			// ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
			throw e;
		} finally {
			closeConnection();
		}
		return rule;
	}

	@Override
	public boolean deleteUser(int userId) throws SQLException {
		// Khởi tạo biến checkDelete kiểu boolean có giá trị bằng false
		boolean checkDelete = false;
		try {
//			Tạo câu truy vấn
			String sql = "delete from tbl_user where user_id = ? ;";
			// Sử dụng PreparedStatement để thực thi câu truy vấn
			PreparedStatement ps = conn.prepareStatement(sql);
//			set giá trị
			ps.setInt(1, userId);
//			Thực thi truy vấn
			int numberRecord = ps.executeUpdate();
			if (numberRecord > 0) {
				checkDelete = true;
			}
		} catch (SQLException e) {
//			Ghi lại log
			System.out.println(this.getClass().getName() + " "
					+ Thread.currentThread().getStackTrace()[1].getMethodName() + " " + e.getMessage());
//			Ném ngoại lệ
			throw e;
		}
//		trả về checkDelete
		return checkDelete;
	}

}
