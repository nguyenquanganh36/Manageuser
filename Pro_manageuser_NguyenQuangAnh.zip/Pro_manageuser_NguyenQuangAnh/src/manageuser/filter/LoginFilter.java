/**
 * copy right luvina
 */
package manageuser.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manageuser.properties.ErrorMessageProperties;
import manageuser.utils.Common;
import manageuser.utils.Constant;

/**
 * Lớp filter thực hiện kiểm tra đăng nhập
 * 
 * @author NGUYEN QUANG ANH
 *
 */
public class LoginFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// lấy ra request
		HttpServletRequest req = (HttpServletRequest) request;
		// lấy ra response
		HttpServletResponse resp = (HttpServletResponse) response;
		try {
			// lấy session
			HttpSession session = req.getSession();
			// lấy về request url
			String requestURL = req.getRequestURI();
			String path = req.getContextPath();
			boolean checkURL = requestURL.endsWith(Constant.LOGIN) || requestURL.equals(path + "/");
			boolean checkLogin = Common.checkLogin(session);
			// nếu đã login và đường dẫn là login hoặc contextroot thì sang
			// adm002
			if (checkLogin && checkURL) {
				// sendredirect sang controller ADM002
				resp.sendRedirect(path + Constant.LISTUSER_URL + "?" + Constant.TYPE + "=" + Constant.DEFAULT);
			} else if (checkLogin && !checkURL || !checkLogin && checkURL) {
				chain.doFilter(request, response);
			} else {
				resp.sendRedirect(req.getContextPath() + Constant.LOGIN);

			}
		} catch (Exception e) {
			req.setAttribute(Constant.ERROR_MESSAGE, ErrorMessageProperties.getValueByKey(Constant.ER015));
			// Chuyển hướng sang màn hình lỗi
			req.getRequestDispatcher(Constant.JSP_SYSTEM_ERRPOR).forward(req, resp);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
